// $Id: Time.h,v 1.1 2007/08/15 02:08:57 tmn Exp $
// $Log: Time.h,v $
// Revision 1.1  2007/08/15 02:08:57  tmn
// Initial revision
//
#include <sys/time.h>
#include <gdbm.h>

typedef struct {
  struct timeval *data;    // $BB,Dj;~4V%G!<%?(B
  int    time_cnt;         // data$B$N%+%&%s%?(B
  int    max;              // $BB,Dj2s?t(B
  int    chk;              // $B%A%'%C%/$9$k2s?t(B
  int    now;              // $B8=:_$N%+%&%s%?(B
  int    time_sts;         // $B;~4VB,Dj%9%F!<%?%9(B
  int    info;             // $B$9$Y$F$N;~4V$r@_Dj$5$l$F$$$l$P(B0$B$G$J$-$c(B1
}timecount_t;

extern void put_time(timecount_t*,int,int);
extern void TimePrint(timecount_t *);
extern int Time_Set(timecount_t *);
extern timecount_t *Time_Start(int , int);
extern void Time_Print(timecount_t *,char *);
extern void Time_Free(timecount_t *);
