// $Id: Time.cc,v 1.1 2007/08/15 02:07:50 tmn Exp $
// $Log: Time.cc,v $
// Revision 1.1  2007/08/15 02:07:50  tmn
// Initial revision
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <gdbm.h>
#include "Time.h"

#ifdef __386_LINUXAS__
#include <time.h>
#endif /* __386_LINUXAS__ */

void put_time(timecount_t *p,int a, int b)
{
  
  struct timeval out_time;
  
  if (p->data[a].tv_usec > p->data[b].tv_usec){
    out_time.tv_sec = p->data[b].tv_sec -p->data[a].tv_sec -1;
    out_time.tv_usec= p->data[b].tv_usec-p->data[a].tv_usec+1000000;
  }
  else{
    out_time.tv_sec = p->data[b].tv_sec -p->data[a].tv_sec;
    out_time.tv_usec= p->data[b].tv_usec-p->data[a].tv_usec;
  }

  fprintf(stderr,":%5d.%06d ( %5d.%06d )\t",
	 out_time.tv_sec,
	 out_time.tv_usec,
         ((out_time.tv_sec)/(p->chk)),
         (((out_time.tv_sec)%(p->chk)*1000000+out_time.tv_usec)/(p->chk)));
  
  if (p->data[0].tv_usec > p->data[b].tv_usec){
    out_time.tv_sec = p->data[b].tv_sec - p->data[0].tv_sec -1;
    out_time.tv_usec= p->data[b].tv_usec-p->data[0].tv_usec+1000000;
  }
  else{
    out_time.tv_sec = p->data[b].tv_sec -p->data[0].tv_sec;
    out_time.tv_usec= p->data[b].tv_usec-p->data[0].tv_usec;
  }
  fprintf(stderr,":%5d.%06d ( %5d.%06d )\n",
	 out_time.tv_sec,
	 out_time.tv_usec,
         out_time.tv_sec/b,
         (out_time.tv_sec%b*(1000000/b)+out_time.tv_usec/b));
}

void TimePrint(timecount_t *p)
{
  int i=0;
  struct tm *st =  localtime(&p->data[0].tv_sec);
  fprintf(stderr,"START_TIME:%04d/%02d/%02d %02d:%02d:%02d.%06d -> ",
           st->tm_year+1900, st->tm_mon+1, st->tm_mday,
           st->tm_hour, st->tm_min, st->tm_sec, p->data[0].tv_usec);
  struct tm *ed =  localtime(&p->data[p->time_cnt-1].tv_sec);
  fprintf(stderr,"END_TIME:%04d/%02d/%02d %02d:%02d:%02d.%06d\n",
           ed->tm_year+1900, ed->tm_mon+1, ed->tm_mday,
           ed->tm_hour, ed->tm_min, ed->tm_sec, p->data[p->time_cnt-1].tv_usec);
  fprintf(stderr,"      MO               Time   (Average:Time/%d)       TOTAL    (Average)\n",p->chk);
 
  for (i=1;i<p->time_cnt;i=i+p->chk){
      if((p->max) >= i+(p->chk)-1){
	  fprintf(stderr,"%5d -> %5d\t",i,i+(p->chk)-1);
	  put_time(p,i-1,i+(p->chk)-1);
      }
  }
}

int Time_Set(timecount_t *p)
{

  if (p->time_sts){
    if ((p->now) > (p->max)){
      fprintf(stderr,"Now(%d) > Max(%d) Error !! Can't set Time\n",p->now,p->max);
      return -1;
    }
    
    p->info = 0;
    gettimeofday(&p->data[p->time_cnt],NULL);
    (p->time_cnt)++;
    if ((p->time_cnt) > (p->max))
	return -1;

    p->now++;
    p->info = (p->now)%(p->chk);
    return 0;
  }
  else {
    fprintf(stderr,"Time Status Error!!\n");
    return -1;
  }
}

timecount_t *Time_Start(int mm, int cc)
{

  timecount_t *p = new timecount_t;

  if (p==NULL){
    fprintf(stderr," Start Error!! (allocate memory)\n");
    return NULL;
  }

  if ( cc == 0 ){
    fprintf(stderr," Start Error!! (Chk==0)\n");
    return NULL;
  }

  if ( mm < cc ){
    fprintf(stderr," Start Error!! (Max < Chk)\n");
    return NULL;
  }

  p->max  = mm;
  p->chk  = cc;
  p->data = (struct timeval *)malloc(sizeof(struct timeval)*(mm+16));
  memset(p -> data,(char)NULL,(sizeof(struct timeval)*(mm+16)));
  p->time_cnt = 0;
  p->now       = 0;
  gettimeofday(&p -> data[p->time_cnt],NULL);
  p->time_cnt++;
  p->now++;
  p->time_sts = 1;
  p->info = 1;
  return p;
}

void Time_Print(timecount_t *p,char *a)
{
  if (p->time_sts){
    
//    if(p->info)
//      Time_Set(p);

    fprintf(stderr,"%s\n",a);
    TimePrint(p);
    Time_Free(p);
  }
}

void Time_Free(timecount_t *p)
{
  free (p->data);
  delete p;
}

/*-----------------------------------------------------------------------*/

