// $Id: userCons.cc,v 1.5 2007-09-10 16:22:20+09 tmn Exp $
// $Log: userCons.cc,v $
// Revision 1.5  2007-09-10 16:22:20+09  tmn
// TMG_ERRORconfirm implement
//
// Revision 1.4  2007/09/05 09:24:17  tmn
// A-RELEASE.INDICATION notify
//
// Revision 1.3  2007/08/17 02:52:43  tmn
// abort command support
//
// Revision 1.2  2007/08/17 02:49:50  tmn
// abort command support
//
// Revision 1.1  2007/08/15 02:24:57  tmn
// Initial revision
//
// vi:ts=4 sw=4
/*
 * (C) Copyright NTT 1996,1997 All rights reserved.
 *
 * This software is furnished under a license and use, duplication, disclosure
 * and all other uses are restricted to the rights specified in the written
 * license between the licensee and NTT.
 */

////////////////////////////////////////////////////////////////////////////////
//
//  Console Event Handling Routines
//
//  X.25 Test Application
//
//  based: alltypes sample
//
////////////////////////////////////////////////////////////////////////////////

#include <sys/time.h>
#include <vector>
#include "../bin/alltypes_mo.h"

#include    "tmgCoEvent.h"

#include "cmUserImpl.h"

#define BUFFER_LEN (2048)

/* 20070927 iseki_add start */
#define INTERVAL  300	/* Operation wait time(1/100 sec) 	*/
#define TIME_WAIT 60	/* Operation response wait time(sec)	*/
#define ASSOCTIME 3 	/* Association Release time wait(sec)	*/
#define DEBUG 1		/* Debug flag 				*/
enum {OFF, ON};		/* flag ON/OFF				*/
enum {ASSOCID, GETID, SETID, EVTID}; 	/* Operations flag 	*/
static int s_assocFlg = OFF;		/* Association flag 	*/
static int s_getFlg = OFF;		/* M-GET flag		*/
static int s_setFlg = OFF;		/* M-SET flag		*/
static int s_evtFlg = OFF;		/* M-EVENTREPORT flag	*/
/* 20070927 iseki_add end */

extern TmgCmUserImpl* g_user ;

std::vector<tmg_string> g_AscList ;

void PrintAscList(int = 0);

/*****************************************************************************/
/* data define */
/*****************************************************************************/
static int   g_iData = 777 ;   // INTEGER (0��2147483647)
#define STRINGDATA_MAX (32)
static char* g_strData = "This is STRING." ; // STRING (Max 32 charactor)
static bool  g_bData = FALSE ;   // BOOLEAN (TRUE or FALSE)

#define LINKEDREPLY_UNIT g_Linkedreply_unit
static int g_Linkedreply_unit = 256 ;
#define STRINGDATALONG_MAX (1024)
static char* g_strDatalong = "01234567890123456789012345678901234567890123456789" ; // STRING LONG VALUE
static tmg_string g_LinkedReplyDataPath ; // LinkedReply data file path

#define STRINGDATA_PTR g_strData
#define STRINGDATALONG_PTR g_strDatalong

static tmg_string g_objStrLinkedReply ; // Store Data for LinkedReply

// 20071015 mochizuki added start
#define STRING_ACTION_ARG001   "Reset ALL"
#define STRING_ACTION_ARG002   "Get ALL"
#define STRING_ACTION_ARG003   "Get Time"

static int g_ACTIONinvokeId = 0 ;
// 20071015 mochizuki added end

/*****************************************************************************/
/* data operation */
/*****************************************************************************/

ASN1::AbstractData * getDataByType( int ) ;
bool setDataByType( int, ASN1::AbstractData& ) ;

ASN1::AbstractData * getIData() ;
ASN1::AbstractData * getStrData(char*) ;
ASN1::AbstractData * getBData() ;
ASN1::AbstractData * getCorrentTime() ;
ASN1::AbstractData * getStrDataLR(char*,int,bool&) ;

bool setIData( ASN1::AbstractData& ) ;
bool setStrData( ASN1::AbstractData&, char*&) ;
bool setBData( ASN1::AbstractData& ) ;

void printIData() ;
void printStrData(char*) ;
void printBData() ;

ASN1::AbstractData * getDataByType( int iType )
{
    switch (iType)
    {
    case 1:
        return getIData() ;
    case 2:
        return getStrData(STRINGDATA_PTR) ;
    case 3:
        return getBData() ;
    case 4:
        return getStrData(STRINGDATALONG_PTR) ;
    case 5:
        return getCorrentTime() ;
    default:
        return NULL ;
    }
}

bool setDataByType( int iType, ASN1::AbstractData& objSetData )
{
    bool bRet ;
    switch (iType)
    {
    case 1:
        return setIData(objSetData) ;
    case 2:
        return setStrData(objSetData,STRINGDATA_PTR) ;
    case 3:
        return setBData(objSetData) ;
    case 4:
        bRet = setStrData(objSetData,STRINGDATALONG_PTR) ;
        if( bRet ) g_LinkedReplyDataPath.remove() ;
        return bRet ;
    default:
        return false ;
    }
}

/*****************************************************************************/
/* INTEGER data operation */
/*****************************************************************************/
ASN1::AbstractData * getIData()
{
    printIData() ;
    // convert to ASN1::INTEGER
    ASN1::AbstractData * retValue = new ASN1::INTEGER(g_iData) ;
    return retValue ;
}

bool setIData( ASN1::AbstractData& Indata )
{
    // type check
    if( Indata.typeGet() != TYPE_ANY ) return false ;

    // decode to ASN1::INTEGER
    ASN1::OpenData * objOpenData = (ASN1::OpenData *)&Indata ;
    if( objOpenData->decode(ASN1::INTEGER::typeStatic()) ){
/* 20071019 error_test support start */
        if( objOpenData->get_data().valGetInt() < 0 ) {
            printf("Invalid value [%d]\n",objOpenData->get_data().valGetInt() ) ;
            return false ;
        }
/* 20071019 error_test support end */
        // modify INTEGER data
        printf("before [%d]\n",g_iData ) ;
        printf("after  [%d]\n",objOpenData->get_data().valGetInt() ) ;
        g_iData = objOpenData->get_data().valGetInt() ;
        return true ;
    } else {
        return false ;
    }
}

void printIData()
{
    printf("INTEGER Value=[%d]\n",g_iData ) ;
}

/*****************************************************************************/
/* STRING data operation */
/*****************************************************************************/
ASN1::AbstractData * getStrData(char* pData)
{
    printStrData(pData) ;
    // convert to ASN1::PrintableString
    ASN1::AbstractData * retValue ;
    char * strEmp = "<data no set>" ;
    if( pData != NULL ){
        retValue = new ASN1::PrintableString(tmg_string(pData)) ;
    } else {
        retValue = new ASN1::PrintableString(tmg_string(strEmp)) ;
    }
    return retValue ;
}

bool setStrData( ASN1::AbstractData& Indata, char*& pData )
{
    // type check
    if( Indata.typeGet() != TYPE_ANY ) return false ;

    // decode to ASN1::PrintableString
    ASN1::OpenData * objOpenData = (ASN1::OpenData *)&Indata ;
    if( objOpenData->decode(ASN1::PrintableString::typeStatic()) ){
        // modify STRING data
        const char * pstrData = objOpenData->get_data().valGetStr() ;
        printf("before [%s]\n",pData ) ;
        printf("after  [%s]\n",pstrData ) ;
        delete [] pData ;
        pData = new char[strlen(pstrData)+1] ;
        strcpy( pData, pstrData ) ;
        return true ;
    } else {
        return false ;
    }
}

void printStrData(char* pData)
{
    printf("STRING Value=[%s]\n",pData ) ;
}

/*****************************************************************************/
/* LONG STRING data operation */
/*****************************************************************************/
ASN1::AbstractData * getStrDataLR(char* pData,int iStart, bool& bIsEmpty)
{
    bIsEmpty = false ;
    // convert to ASN1::PrintableString
    ASN1::AbstractData * retValue ;
    char * strEmp = "<data no set>" ;
    if( pData != NULL ){
        tmg_string strWk(pData) ;
        if( iStart >= (int)strWk.size()){
            // when iStart is out of range , return <data no set>
            retValue = new ASN1::PrintableString(tmg_string(strEmp)) ;
            bIsEmpty = true ;
        } else {
            retValue = new ASN1::PrintableString( strWk.substr(iStart,LINKEDREPLY_UNIT) ) ;
            if( (iStart + LINKEDREPLY_UNIT) >= (int)strWk.size() ){
                // when end of data, bIsEmpty set true 
                bIsEmpty = true ;
            }
        }
    } else {
        if( g_LinkedReplyDataPath.size() > 0 ){
            // when data file path is exist

            // read data
            char pReadStr[LINKEDREPLY_UNIT+1] ;
            memset( pReadStr,0,LINKEDREPLY_UNIT+1 ) ;
            FILE* fp = fopen( g_LinkedReplyDataPath.c_str(), "r" ) ;
            if ( !fp ){
                retValue = new ASN1::PrintableString(tmg_string(strEmp)) ;
                // when data is empty , bIsEmpty set true ;
                bIsEmpty = true ;
                return retValue ;
            }
            
            if( fseek( fp, iStart, SEEK_SET ) == -1 ){
                fclose (fp) ;
                retValue = new ASN1::PrintableString(tmg_string(strEmp)) ;
                // when data is empty , bIsEmpty set true ;
                bIsEmpty = true ;
                return retValue ;
            }
            if( fread( pReadStr, 1, LINKEDREPLY_UNIT, fp ) < 1 ){
                fclose (fp) ;
                retValue = new ASN1::PrintableString(tmg_string(strEmp)) ;
                // when data is empty , bIsEmpty set true ;
                bIsEmpty = true ;
                return retValue ;
            }
            fclose(fp) ;

            // set PrintableString
            retValue = new ASN1::PrintableString(tmg_string(pReadStr)) ;

            // when end of data, bIsEmpty set true 
            struct stat objStat ;
            if( stat( g_LinkedReplyDataPath.c_str(), &objStat ) == -1 ){
                bIsEmpty = true ;
            } else {
                if( objStat.st_size <= iStart + LINKEDREPLY_UNIT ){
                    bIsEmpty = true ;
                }
            }

        } else {
            retValue = new ASN1::PrintableString(tmg_string(strEmp)) ;
            // when data is empty , bIsEmpty set true ;
            bIsEmpty = true ;
        }
    }
    return retValue ;
}

/*****************************************************************************/
/* BOOLEAN data operation */
/*****************************************************************************/
ASN1::AbstractData * getBData()
{
    printBData() ;

    // convert to ASN1::BOOLEAN
    ASN1::AbstractData * retValue = new ASN1::BOOLEAN(g_bData) ;
    return retValue ;
}

bool setBData( ASN1::AbstractData& Indata )
{
    // type check
    if( Indata.typeGet() != TYPE_ANY ) return false ;

    // decode to ASN1::BOOLEAN
    ASN1::OpenData * objOpenData = (ASN1::OpenData *)&Indata ;
    if( objOpenData->decode(ASN1::BOOLEAN::typeStatic()) ){
        // modify BOOLEAN data
        printf("before [%d]\n",g_bData ) ;
        printf("after  [%d]\n",objOpenData->get_data().valGetInt() ) ;
        g_bData = objOpenData->get_data().valGetInt() ;
        return true ;
    } else {
        return false ;
    }
}

void printBData()
{
    if( g_bData )
        printf("BOOLEAN Value=[TRUE]\n" ) ;
    else
        printf("BOOLEAN Value=[FALSE]\n" ) ;
}

/*****************************************************************************/
/* CURRENTTIME data operation */
/*****************************************************************************/
ASN1::AbstractData * getCorrentTime()
{
    // get current time
    struct timeval objTv ;
    gettimeofday( &objTv,NULL );

    // convert from second to ASN1::INTEGER
    ASN1::AbstractData * retValue = new ASN1::INTEGER(objTv.tv_sec) ;

    return retValue ;
}

/*****************************************************************************/

void PrintAscList(int iFirstIndex)
{
    // display associated name
    printf("PrintAscList start\n");
    int i = iFirstIndex ;
    for( std::vector<tmg_string>::iterator it = g_AscList.begin(); it != g_AscList.end(); it++ ){
        printf("\t[%02d] %s\n",i,it->c_str());
        i++ ;
    }
    printf("PrintAscList end  \n");

}

TmgCmUserImpl::TmgCmUserImpl() :
invoke_count(0)
{
}

TmgCmUserImpl::~TmgCmUserImpl()
{
}


/*****************************************************************************/
/* Manager side */
/*****************************************************************************/
void TmgCmUserImpl::TmgAscInd(int caId, TmgApcPaddr *pa, ASN1::AbstractData *cxnName,
                              TmgApcOct *cldApt, TmgApcOct *cldAeq, int cldApi, int cldAei,
                              TmgApcOct *clgApt, TmgApcOct *clgAeq, int clgApi, int clgAei,
                              A_CMIPUserInfo *uInfo, TmgApcOct *rspApt, int cid )
{

    printf("TmgCmUserImpl::TmgAscInd\n") ;
    printf("ASSOC-Indication receive\n") ;

    TmgAtPrint(cxnName) ;

    // insert cxnName to g_AscList
    if( cxnName->lengthGet() > 0 ){
        char * pcxnNameStr = new char[cxnName->lengthGet()+1] ;
        memset( pcxnNameStr,0,cxnName->lengthGet()+1 ) ;
        memcpy( pcxnNameStr, cxnName->valGetStr(), cxnName->lengthGet() ) ;

        g_AscList.push_back(tmg_string(pcxnNameStr)) ;
        delete [] pcxnNameStr ;
    } else {
        printf("cxnName->lengthGet() equal 0\n") ;
    }

    TmgOpUser::TmgAscInd(caId,pa,cxnName,cldApt,cldAeq,cldApi,cldAei,clgApt,clgAeq,clgApi,clgAei,uInfo,rspApt,cid) ;

}


/* iseki_add start */
void TmgCmUserImpl::TmgAscCrtCnf(TmgCmAscEnumState result, int invoke, int cid)
{
    fprintf(stderr, "Receive Conection Create Response(TmgOpCmipPlus). \
        result=%d invoke=%d cid=%d\n", result, invoke, cid);
    fflush(stderr);

    if(result == tmgCmAscCrt) {
        fprintf(stderr, "Association Success establishment(TmgCmUserImpl).\n");
        fflush(stderr);
#if DEBUG
        fprintf(stdout, "Association Success establishment(TmgCmUserImpl).---[:-)]---%d\n", s_assocFlg);
        fflush(stdout);
#endif
        s_assocFlg = OFF; /* ASSOCIATION�ե饰OFF */
    }
    else if(result == tmgCmAscExist) {
        fprintf(stderr, "Exist Association establishment(TmgCmUserImpl).\n");
        fflush(stderr);
#if DEBUG
        fprintf(stdout, "Exist Association establishment(TmgCmUserImpl).---[:-<]\n");
        fflush(stdout);
#endif
        s_assocFlg = OFF; /* ASSOCIATION�ե饰OFF */
    }
    else {
        fprintf(stderr, "Failed Association establishment(TmgCmUserImpl).---[:-(]\n");
        fflush(stderr);
#if DEBUG
        fprintf(stdout, "Failed Association establishment(TmgCmUserImpl).---[:-(|)]\n");
        fflush(stdout);
#endif
    }
}
/* iseki_add end */


void TmgCmUserImpl::TMG_GETconfirm(ASN1::AbstractData* mes, int invoke, int linkId, int cid)
{

    printf("TmgCmUserImpl::TMG_GETconfirm start\n") ;
    printf("M-GET Response receive---[:3)]\n") ;

    // display message value

    // analyze M-GET response message
    A_GetRes * objGetRes = (A_GetRes*)mes ;
    A_XAtr & objXAtr = objGetRes->ref_attributeList() ;
    ASN1::INTEGER & objAttrId = (*(objXAtr.begin())).ref_attributeId().ref_localForm() ;
    ASN1::AbstractData & objAttrVal = (*(objXAtr.begin())).ref_attributeValue() ;
    ASN1::OpenData * objOpenData = (ASN1::OpenData*)&objAttrVal ;

    int iINTEGERvalue ;

    switch( objAttrId.valGetInt() ){
    case 1:
        // decode to ASN1::INTEGER
        if( objOpenData->decode(ASN1::INTEGER::typeStatic()) ){
            // display INTEGER data
            iINTEGERvalue = objOpenData->get_data().valGetInt() ;
            printf("INTEGER value [%d]\n",iINTEGERvalue) ;
        }
        break ;
    case 2:
        // decode to ASN1::PrintableString
        if( objOpenData->decode(ASN1::PrintableString::typeStatic()) ){
            // display STRING data
            printf("STRING value [%s]\n",objOpenData->get_data().valGetStr()) ;
        }
        break ;
    case 3:
        // decode to ASN1::BOOLEAN
        if( objOpenData->decode(ASN1::BOOLEAN::typeStatic()) ){
            // display BOOLEAN data
            if( objOpenData->get_data().valGetInt() ){
                printf("BOOLEAN value [TRUE]\n") ;
            } else {
                printf("BOOLEAN value [FALSE]\n") ;
            }
        }
        break ;
    case 4:
        // decode to ASN1::PrintableString
        if( objOpenData->decode(ASN1::PrintableString::typeStatic()) ){
            // Store Response Data, until NullResponse receive
            g_objStrLinkedReply += objOpenData->get_data().valGetStr() ;
        }
        printf("receive invokeId[%d] LinkId[%d]\n",invoke,linkId) ;
        break ; 
    case 5:
        // decode to ASN1::INTEGER
        if( objOpenData->decode(ASN1::INTEGER::typeStatic()) ){
            // display Time
            time_t iSec = objOpenData->get_data().valGetInt() ;
            printf("TIME value ->%s",ctime(&iSec)) ;
        }
        break ;
    default:
        break ;
    }

/* 20070927 iseki_add */
    s_getFlg = OFF;

    printf("TmgCmUserImpl::TMG_GETconfirm end  \n") ;
}


void TmgCmUserImpl::TMG_SETconfirm(ASN1::AbstractData* mes, int invoke, int linkId, int cid)
{
    printf("TmgCmUserImpl::TMG_SETconfirm start\n") ;
    printf("M-SET Response receive---[8-)]\n") ;

    // display message value
    TmgAtPrint(mes) ;

/* 20070927 iseki_add */
    s_setFlg = OFF;

    printf("TmgCmUserImpl::TMG_SETconfirm end  \n") ;

}


void TmgCmUserImpl::TMG_ACTIONconfirm(ASN1::AbstractData* mes, int invoke, int linkId,
                                     int cid)
{
    printf("TmgCmUserImpl::TMG_ACTIONconfirm start\n") ;
    printf("M-ACTION Response receive \n") ;

    // display message value
// 20071015 mochizuki deleted start
//    TmgAtPrint(mes) ;
// 20071015 mochizuki deleted end


// 20071015 mochizuki added start
    if( mes ){

        if( g_ACTIONinvokeId > 0 && linkId == g_ACTIONinvokeId ){
            printf("Linked Reply invokeId[%d], linkId[%d]\n",invoke,linkId) ;
        }

        A_ActRes * objActRes = (A_ActRes*)mes  ;

        int iActType = objActRes->get_actionReply().get_actionType().get_localForm() ;

        switch( iActType ){
        case 1 :
            {
                int iINTEGERvalue ;
                ASN1::AbstractData& objInfo = objActRes->ref_actionReply().ref_actionReplyInfo() ;
                ASN1::OpenData * pobjOpen = (ASN1::OpenData*)&objInfo ;
                if( pobjOpen->decode( ASN1::INTEGER::typeStatic()) ) {
                    iINTEGERvalue = pobjOpen->get_data().valGetInt() ;
                    printf("INTEGER value [%d]\n",iINTEGERvalue) ;
                } else {
                    printf("INTEGER value [decode error]\n") ;
                }
            }
            break ;
        case 2 :
            {
                ASN1::AbstractData& objInfo = objActRes->ref_actionReply().ref_actionReplyInfo() ;
                ASN1::OpenData * pobjOpen = (ASN1::OpenData*)&objInfo ;
                if( pobjOpen->decode( ASN1::PrintableString::typeStatic()) ){
                    printf("STRING value [%s]\n",pobjOpen->get_data().valGetStr()) ;
                } else {
                    printf("STRING value [decode error]\n") ;
                }
            }
            break; 
        case 3:
            {
                ASN1::AbstractData& objInfo = objActRes->ref_actionReply().ref_actionReplyInfo() ;
                ASN1::OpenData * pobjOpen = (ASN1::OpenData*)&objInfo ;
                if( pobjOpen->decode(ASN1::BOOLEAN::typeStatic()) ){
                    if( pobjOpen->get_data().valGetInt() ){
                        printf("BOOLEAN value [TRUE]\n") ;
                    } else {
                        printf("BOOLEAN value [FALSE]\n") ;
                    }
                } else {
                    printf("BOOLEAN value [decode error]\n") ;
                }
            }
            break ;
        case 5 :
            {
                ASN1::AbstractData& objInfo = objActRes->ref_actionReply().ref_actionReplyInfo() ;
                ASN1::OpenData * pobjOpen = (ASN1::OpenData*)&objInfo ;
                if( pobjOpen->decode(ASN1::INTEGER::typeStatic()) ){
                    time_t iSec = pobjOpen->get_data().valGetInt() ;
                    printf("TIME value ->%s",ctime(&iSec)) ;
                } else {
                    printf("TIME value [decode error]\n") ;
                }
            }
        default :
            break; 
        }
        
    }

    delete mes ;

// 20071015 mochizuki added end

// 20071015 mochizuki modified start
//    printf("TmgCmUserImpl::TMG_ACTIONconfirm end \n") ;
    printf("TmgCmUserImpl::TMG_ACTIONconfirm end \n\n") ;
// 20071015 mochizuki modified end

}


void TmgCmUserImpl::TMG_EVENTindication(ASN1::AbstractData* mes, ASN1::AbstractData* name,
                                       int invoke, int conf, int cid)
{

    printf("TmgCmUserImpl::TMG_EVENTindication start\n") ;
    printf("M-EVENT-REPORT From ") ;
    TmgAtPrint(name) ;
    TmgAtPrint(mes) ;

    // analyze M-EVENT-REPORT request parameter
    A_EvtRepArg * objEvtArg = (A_EvtRepArg*)mes ;

    ASN1::AbstractData * objEvtInfo = objEvtArg->get_eventInfo().dup() ;

    printf("M-EVENT-REPORT ...\n") ;
    if( objEvtInfo->typeGet() == TYPE_ANY ){
        // display message
        ASN1::OpenData * pOpenData = (ASN1::OpenData*)objEvtInfo ;
        if( pOpenData->decode(ASN1::PrintableString::typeStatic()) ){
            printf("message [%s]\n",pOpenData->get_data().valGetStr()) ;
        } else {
            printf("decode failed\n") ;
        }
    }

/* 20070927 iseki_add */
    s_evtFlg = OFF;
 
    printf("TmgCmUserImpl::TMG_EVENTindication end \n") ;

}


void TmgCmUserImpl::TMG_NULLconfirm(int invoke, int cid)
{
    printf("TmgCmUserImpl::TMG_NULLconfirm start\n") ;
    printf("NULL confirm receive---[8-}]\n") ;

    // display stored LinkedReply Data
    printf("invoke[%d]\n",invoke) ;

// 20071015 mochizuki modified start
   if( g_objStrLinkedReply.size() > 0 ){
       printf("STRING value is ... \n%s\n",g_objStrLinkedReply.c_str()) ;
   }
// 20071015 mochizuki modified end

    // clearing stored LinedReply Data
    g_objStrLinkedReply.remove() ;

// 20071015 mochizuki added start
    g_ACTIONinvokeId = 0 ;
// 20071015 mochizuki added end

    printf("TmgCmUserImpl::TMG_NULLconfirm end  \n") ;
}


void TmgCmUserImpl::TMG_ERRORconfirm(ASN1::AbstractData *arg, int invoke, int cid)
{
    printf("TmgCmUserImpl::TMG_ERRORconfirm start\n") ;
    printf("invoke = %d, cid = %d\n",invoke,cid) ;

    TmgAtPrint(arg) ;

/* 20070926 iseki_debug */
/*
    A_InvokeError * pInvErr = (A_InvokeError*)arg ;
    ASN1::OCTET_STRING dstName = ((A_ErrObjInst&)pInvErr->get_parameter()).get_nonSpecificForm() ;
    printf("dstName is ") ;
    TmgAtPrint(&dstName) ;
*/
    printf("TmgCmUserImpl::TMG_ERRORconfirm end---[8-<]\n") ;

}


/*****************************************************************************/
/* Agent side */
/*****************************************************************************/
void TmgCmUserImpl::TMG_GETindication(ASN1::AbstractData* mes, ASN1::AbstractData* name, int
invoke, int cid)
{

    printf("TmgCmUserImpl::TMG_GETindication\n") ;
    printf("M-GET Request From ") ;
    TmgAtPrint(name) ;

    // analyze M-GET request parameter
    A_GetArg * objGetArg = (A_GetArg*)mes ;
    A_XAtrId::const_iterator objAttrId = objGetArg->get_attributeIdList().begin() ;
    ASN1::INTEGER AttrId = (*objAttrId).get_localForm() ; 

/* 20071019 error_test support start */
    if( AttrId.valGetInt() < 1 || AttrId.valGetInt() > 5 ){
        // send noSuchAttributeId Error
        A_ErrorStatus * objErrStatus = new A_ErrorStatus ;
        objErrStatus->set_noSuchAttributeId() ;

        A_ErrAtrId * objErrAtrId = new A_ErrAtrId( A_AttributeId::localForm::id, AttrId ) ;

        sendInvokeError( objErrStatus, objErrAtrId, name, invoke ) ; 

        delete objErrStatus ;
        delete objErrAtrId ;
        delete mes ;
        return ;
    }
/* 20071019 error_test support start */

    if( AttrId.valGetInt() != 4 ){ 
    // edit M-GET response message for type INTEGER,STRING,BOOLEAN,TIME

        // get data by type
        ASN1::AbstractData * objAttrValue = getDataByType( AttrId.valGetInt() ) ;
        if( !objAttrValue ){
            printf("operation Imcomplete [objAttrValue is NULL]") ;
            return ;
        }

        // edit M-GET response message
        //     attributeid & attributevalue
        A_Attribute * objAttribute = new A_Attribute( 
                          *(objGetArg->get_attributeIdList().begin()), *objAttrValue ) ;
        A_XAtr * objXAtr = new A_XAtr( *objAttribute ) ;

        //     corrent time
        struct timeval objTv ;
        gettimeofday( &objTv,NULL );
        struct tm * plocal = localtime( &objTv.tv_sec ) ;
        ASN1::GeneralizedTime * objNow = new ASN1::GeneralizedTime(
                                                 plocal->tm_year+1900,
                                                 plocal->tm_mon+1 ,
                                                 plocal->tm_mday,
                                                 plocal->tm_hour,
                                                 plocal->tm_min,
                                                 plocal->tm_sec,
                                                 objTv.tv_usec/1000
                                                 ) ;
    
        A_GetRes * objGetRes = new A_GetRes( &(objGetArg->get_baseManagedObjectClass()),
                                     &(objGetArg->get_baseManagedObjectInstance()),
                                     objNow,objXAtr ) ;

        // send M-GET response message
        g_user->TmgResponse( objGetRes, name, invoke ) ;

        delete objAttrValue ;
        delete objAttribute ;
        delete objXAtr ;
        delete objNow ;

    } else {
    // edit M-GET response message for type LONG STRING
        bool IsEmpty = false ;
        ASN1::AbstractData * objAttrValue ;
        A_Attribute * objAttribute ;
        A_XAtr * objXAtr ;

        struct timeval objTv ;
        struct tm * plocal ;
        ASN1::GeneralizedTime * objNow ;
        A_GetRes * objGetRes ;

        int iPos = 0 ;
        // while data is end
        while( !IsEmpty ){
            // get data by type
            objAttrValue = getStrDataLR( STRINGDATALONG_PTR, iPos, IsEmpty ) ;
            if( !objAttrValue ){
                printf("operation Imcomplete [objAttrValue is NULL]") ;
                return ;
            }
            // edit M-GET response message
            //     attributeid & attributevalue
            objAttribute = new A_Attribute( 
                        *(objGetArg->get_attributeIdList().begin()), *objAttrValue ) ;
            objXAtr = new A_XAtr( *objAttribute ) ;

            //     corrent time
            gettimeofday( &objTv,NULL );
            plocal = localtime( &objTv.tv_sec ) ;
            objNow = new ASN1::GeneralizedTime(
                                             plocal->tm_year+1900,
                                             plocal->tm_mon+1 ,
                                             plocal->tm_mday,
                                             plocal->tm_hour,
                                             plocal->tm_min,
                                             plocal->tm_sec,
                                             objTv.tv_usec/1000
                                             ) ;
    
            objGetRes = new A_GetRes( &(objGetArg->get_baseManagedObjectClass()),
                                 &(objGetArg->get_baseManagedObjectInstance()),
                                 objNow,objXAtr ) ;
            // send M-GET response message
            g_user->TmgLinkedReply( objGetRes, name->dup(), g_user->getInvokeId(), invoke ) ;

            delete objAttrValue ;
            delete objAttribute ;
            delete objXAtr ;
            delete objNow ;

            // increment iPos
            iPos += LINKEDREPLY_UNIT ;

        } // while( !IsEmpty )
        g_user->TmgNullResponse( name, invoke ) ;

    } // if( AttrId.valGetInt() != 4 )

    delete mes ;

    return ;
}


void TmgCmUserImpl::TMG_SETindication(ASN1::AbstractData* mes, ASN1::AbstractData* name,
                                      int invoke, int conf, int cid)
{

    printf("TmgCmUserImpl::TMG_SETindication\n") ;
    printf("M-SET Request From ") ;
    TmgAtPrint(name) ;

    // analyze M-SET request parameter
    A_SetArg * objSetArg = (A_SetArg*)mes ;

    A_XMdfyLst::const_iterator objMdfy = objSetArg->get_modificationList().begin() ;
    ASN1::INTEGER AttrId = (*objMdfy).get_attributeId().get_localForm() ;
/* 20071019 error_test support start */
    if( AttrId.valGetInt() < 1 || AttrId.valGetInt() > 4 ){
        // send noSuchAttributeId Error
        A_ErrorStatus * objErrStatus = new A_ErrorStatus ;
        objErrStatus->set_noSuchAttributeId() ;

        A_ErrAtrId * objErrAtrId = new A_ErrAtrId( A_AttributeId::localForm::id, AttrId ) ;

        sendInvokeError( objErrStatus, objErrAtrId, name, invoke ) ;

        delete objErrStatus ;
        delete objErrAtrId ;
        delete mes ;
        return ;
    }
/* 20071019 error_test support end   */
    ASN1::AbstractData * objAttrValue = (*objMdfy).get_attributeValue().dup() ;

    // set value by type
    if( ! setDataByType( AttrId.valGetInt(), *objAttrValue ) ){
        printf("\nM-SET failed (..); \n") ;
/* 20071019 error_test support start */
        // send invalidAttributeValue Error
        A_ErrorStatus * objErrStatus = new A_ErrorStatus ;
        objErrStatus->set_invalidAttributeValue() ;

        A_ErrAtr * objErrAtr = new A_ErrAtr( (*objMdfy).get_attributeId(),
                                             (*objMdfy).get_attributeValue() ) ;

        sendInvokeError( objErrStatus, objErrAtr, name, invoke ) ;

        delete objErrStatus ;
        delete objErrAtr ;
        delete mes ;
/* 20071019 error_test support end */
        return ;
    }

    // edit M-SET response message
    //     currentTime
    struct timeval objTv ;
    gettimeofday( &objTv,NULL );
    struct tm * plocal = localtime( &objTv.tv_sec ) ;
    ASN1::GeneralizedTime * objNow = new ASN1::GeneralizedTime(
                                             plocal->tm_year+1900,
                                             plocal->tm_mon+1 ,
                                             plocal->tm_mday,
                                             plocal->tm_hour,
                                             plocal->tm_min,
                                             plocal->tm_sec,
                                             objTv.tv_usec/1000
                                             ) ;
    
    //     attributeId & attributevalue
    A_Attribute * objAttribute = new A_Attribute( (*objMdfy).get_attributeId(),
                                                 (*objMdfy).get_attributeValue() ) ;
    A_XAtr * objXAtr = new A_XAtr( *objAttribute ) ;

    A_SetRes * objSetRes = new A_SetRes( &(objSetArg->get_baseManagedObjectClass()),
                                 &(objSetArg->get_baseManagedObjectInstance()),
                                 objNow,objXAtr ) ;

    // send M-SET response message
    g_user->TmgResponse( objSetRes, name, invoke ) ;

    delete objAttrValue ;
    delete objNow ;
    delete objAttribute ;
    delete objXAtr ;
    delete mes ;

    return ;
}


void TmgCmUserImpl::TMG_ACTIONindication(ASN1::AbstractData* mes, ASN1::AbstractData* name,
                                      int invoke, int conf, int cid)
{

    printf("TmgCmUserImpl::TMG_ACTIONindication\n") ;
    printf("M-ACTION Request From ") ;
    TmgAtPrint(name) ;

    // analyze M-ACTION request parameter
    A_ActArg * objActArg = (A_ActArg*)mes ;


// 20071015 mochizuki added start
    A_ActInf& objActInfo = objActArg->ref_actionInfo() ;
    ASN1::AbstractData& objActparam = objActInfo.ref_actionArgument() ;

    ASN1::OpenData * pOpenData = (ASN1::OpenData*)&objActparam ;

    tmg_string strActparam ;

    if( pOpenData->decode(ASN1::PrintableString::typeStatic()) ){
        strActparam = pOpenData->valGetStr() ;
    } else {
        printf("decode error\n") ;
    }
   
    if( strActparam == STRING_ACTION_ARG001 ){
        // execute Reset all object
        g_iData = 0 ;
        g_strData = NULL ;
        g_bData = FALSE ;
        g_strDatalong = NULL ;
        g_LinkedReplyDataPath = "" ;

        printf("Reset all object , complete \n") ;

    } else if( strActparam == STRING_ACTION_ARG002 ){
        // execute Get all object
        ASN1::AbstractData * objAttrValue = NULL ;
        A_ActRply * objActRply = NULL ;
        A_ActRes * objActRes = NULL ;

        for( int i=1 ; i<4 ; i++ ){
            objAttrValue = getDataByType( i ) ;
            if( !objAttrValue ){
                continue ;
            }

            // edit M-ACTION response parameter
            //     currentTime
            struct timeval objTv ;
            gettimeofday( &objTv,NULL );
            struct tm * plocal = localtime( &objTv.tv_sec ) ;

            ASN1::GeneralizedTime * objNow = new ASN1::GeneralizedTime(
                                             plocal->tm_year+1900,
                                             plocal->tm_mon+1 ,
                                             plocal->tm_mday,
                                             plocal->tm_hour,
                                             plocal->tm_min,
                                             plocal->tm_sec,
                                             objTv.tv_usec/1000
                                             ) ;

            // edit M-ACTION response message
            objActRply = new A_ActRply ;
//            objActRply->set_actionType( objActArg->get_actionInfo().get_actionType() ) ;
            A_ActTypId * objActTypId = new A_ActTypId( A_ActTypId::localForm::id, ASN1::INTEGER(i) ) ;
            objActRply->set_actionType( *objActTypId ) ;
            objActRply->set_actionReplyInfo( *objAttrValue ) ;

            objActRes = new A_ActRes( &(objActArg->get_baseManagedObjectClass()),
                                 &(objActArg->get_baseManagedObjectInstance()),
                                 objNow,objActRply ) ;

            // send M-ACTION response parameter (Linked Reply)
            g_user->TmgLinkedReply( objActRes, name->dup(), g_user->getInvokeId(), invoke ) ;

            delete objAttrValue ;
            delete objActRply ;
            delete objActTypId ;
            delete objNow ;

        }

        g_user->TmgNullResponse( name, invoke ) ;

        delete mes ;
        return ;

    } else if( strActparam == STRING_ACTION_ARG003 ){
        // execute Get Time object
        ASN1::AbstractData * objAttrValue = NULL ;
        A_ActRply * objActRply = NULL ;
        A_ActRes * objActRes = NULL ;

        objAttrValue = getDataByType( 5 ) ;

        // edit M-ACTION response parameter
        //     currentTime
        struct timeval objTv ;
        gettimeofday( &objTv,NULL );
        struct tm * plocal = localtime( &objTv.tv_sec ) ;

        ASN1::GeneralizedTime * objNow = new ASN1::GeneralizedTime(
                                             plocal->tm_year+1900,
                                             plocal->tm_mon+1 ,
                                             plocal->tm_mday,
                                             plocal->tm_hour,
                                             plocal->tm_min,
                                             plocal->tm_sec,
                                             objTv.tv_usec/1000
                                             ) ;
        // edit M-ACTION response message
        objActRply = new A_ActRply ;
        A_ActTypId * objActTypId = new A_ActTypId( A_ActTypId::localForm::id, ASN1::INTEGER(5) ) ;
        objActRply->set_actionType( *objActTypId ) ;
        objActRply->set_actionReplyInfo( *objAttrValue ) ;

        objActRes = new A_ActRes( &(objActArg->get_baseManagedObjectClass()),
                                  &(objActArg->get_baseManagedObjectInstance()),
                                  objNow,objActRply ) ;
 
        // send M-ACTION response parameter
        g_user->TmgResponse( objActRes, name, invoke ) ;

        delete objAttrValue ;
        delete objNow ;
        delete objActTypId ;
        delete objActRply ;
        delete mes ;
        return ;
/* 20071019 error_test support start */
    } else {
        // invalidArgumentValue Error
        A_ErrorStatus * objErrStatus = new A_ErrorStatus ;
        objErrStatus->set_invalidArgumentValue() ;

        A_InvldArgVl * objInvldArgVl = new A_InvldArgVl( A_InvldArgVl::actionValue::id,
                                                         objActInfo ) ;

        sendInvokeError( objErrStatus, objInvldArgVl, name, invoke ) ;

        delete objErrStatus ;
        delete objInvldArgVl ;
        delete mes ;
        return ;
/* 20071019 error_test support end */
    }

    // return , if no confirmed mode 
    if( conf == TMG_NO_CONFIRMED_REQUEST ){
        delete name ;
        delete mes ;
        printf("no send Reply.\n") ;
        return ;
    }

// 20071015 mochizuki added end
    // response for TWINS simulator 

    // edit M-ACTION response parameter
    //     currentTime
    struct timeval objTv ;
    gettimeofday( &objTv,NULL );
    struct tm * plocal = localtime( &objTv.tv_sec ) ;

    ASN1::GeneralizedTime * objNow = new ASN1::GeneralizedTime(
                                             plocal->tm_year+1900,
                                             plocal->tm_mon+1 ,
                                             plocal->tm_mday,
                                             plocal->tm_hour,
                                             plocal->tm_min,
                                             plocal->tm_sec,
                                             objTv.tv_usec/1000
                                             ) ;
 
    //     actionReply
    A_ActRply * objActRply = new A_ActRply ;
    objActRply->set_actionType( objActArg->get_actionInfo().get_actionType() ) ;
    ASN1::AbstractData * objActRplyInfo = new ASN1::OCTET_STRING(tmg_string("ACTION END")) ;
    objActRply->set_actionReplyInfo(*objActRplyInfo) ;

    A_ActRes * objActRes = new A_ActRes( &(objActArg->get_baseManagedObjectClass()),
                                 &(objActArg->get_baseManagedObjectInstance()),
                                 objNow,objActRply ) ;

    // send M-ACTION response parameter
    g_user->TmgResponse( objActRes, name, invoke ) ;

    delete objNow ;
    delete objActRply ;
    delete objActRplyInfo ;
    delete mes ;

    return ;

}


void TmgCmUserImpl::TMG_ASSOC_ERRORindication(ASN1::AbstractData* name, int cid)
{
    printf("TmgCmUserImpl::TMG_ASSOC_ERRORindication---[:-0]\n") ;
    printf("ASSOC RELEASE or ABORT From ") ;
    TmgAtPrint(name) ;

    delete name ;
}


void TmgCmUserImpl::TmgAscRelInd(ASN1::AbstractData *name, int cidmsk)
{
    printf("TmgCmUserImpl::TmgAscRelInd\n") ;
    printf("A-RELEASE.INDICATION From ") ;
    TmgAtPrint(name) ;

    // delete name to g_AscList
    if( !name ) return ;

    if( name->lengthGet() > 0 ){
        char *pchName = new char[name->lengthGet()+1] ;
        memset( pchName, 0, name->lengthGet()+1 ) ;
        memcpy( pchName, name->valGetStr(), name->lengthGet() ) ;

        std::vector<tmg_string>::iterator it ;
        for( it = g_AscList.begin(); it != g_AscList.end(); it++ ){
            if( *it == pchName ){
                g_AscList.erase(it) ;
                break ;
            }
        }
        delete [] pchName ;
    }

    delete name ;
}


void TmgCmUserImpl::TMG_ERRORindication(ASN1::AbstractData *arg, int invoke, int cid)
{

    printf("TmgCmUserImpl::TMG_ERRORindication start\n") ;

    printf("invoke = %d, cid = %d\n",invoke,cid) ;

    TmgAtPrint(arg) ;

/*
    A_InvokeError * pInvErr = (A_InvokeError*)arg ;
    ASN1::OCTET_STRING dstName = ((A_ErrObjInst&)pInvErr->get_parameter()).get_nonSpecificForm() ;
    printf("dstName is ") ;
    TmgAtPrint(&dstName) ;
*/

    printf("TmgCmUserImpl::TMG_ERRORindication end\n") ;

}


////////////////////////////////////////////////////////////////////////////////
// DN̾���������ؿ�
////////////////////////////////////////////////////////////////////////////////
static ASN1::AbstractData *GetEntityName(const char *rdnStr)
{
   ASN1::AbstractData *name;
   name =(ASN1::AbstractData*) new ASN1::OCTET_STRING;
   name->lengthSet(strlen(rdnStr));
   name->valSetStr(rdnStr);
   TmgAtPrint(name);
   return       name;
}

/* 20071019 error_test support start */
////////////////////////////////////////////////////////////////////////////////
// InvokeError�����ؿ�
// parameters
//   errStatus : Error Status
//   errParam  : Error detail
//   name      : Distination name
//   invoke    : Invoke ID
////////////////////////////////////////////////////////////////////////////////
void TmgCmUserImpl::sendInvokeError( const A_ErrorStatus* errStatus,
   const ASN1::AbstractData* errParam, ASN1::AbstractData* name, int invoke )
{
   // create InvokeError instance
   A_InvokeError * objInvErr = new A_InvokeError(NULL, *errStatus, errParam ) ;

   // send InvokeError
   g_user->TmgResponse( objInvErr, name, invoke ) ;

}
/* 20071019 error_test support end */

////////////////////////////////////////////////////////////////////////////////
// ���ּ����Ѵؿ�
////////////////////////////////////////////////////////////////////////////////
/* 20070320 iseki_add start */
double Time()
{
    struct tm *tp;
    struct timeval tv;

    gettimeofday(&tv, NULL);
    tp = localtime(&tv.tv_sec);
    return tv.tv_sec + (double)tv.tv_usec * 1e-6;
}
/* 20070320 iseki_add end */


/* 20070927 iseki_add start */
////////////////////////////////////////////////////////////////////////////////
// ���ڥ졼������Ԥ����ִƻ�ؿ�
////////////////////////////////////////////////////////////////////////////////
int waitOp(int cmipFlg)
{
    double tstart, tend;

    tstart = Time(); /* ���ϻ��� */
    for(;;) {
        switch(cmipFlg) {
            case ASSOCID: /* CMIP��������������󥳥ޥ�� */
                if(s_assocFlg == OFF)
                    return 0;
                break;
            case GETID: /* M-GET���ޥ�� */
                if(s_getFlg == OFF)
                    return 0;
                break;
            case SETID: /* M-SET���ޥ�� */
                if(s_setFlg == OFF)
                    return 0;
                break;
            case EVTID: /* M-EVENTREPORT���ޥ�� */
                if(s_evtFlg == OFF)
                    return 0;
                break;
            default:	/* ̵���ʥ��ޥ�� */
                fprintf(stdout, "No match CMIP Operation.\n");
                fflush(stdout);
                return -1;
        }
        ApplicationList::EventSleep(INTERVAL);
        tend = Time(); /* ��λ���� */

        fprintf(stdout,"s_assocFlg:%d\n", s_assocFlg);
        fflush(stdout);

        /* �������(WAIT_TIME)�򥪡��С������饪�ڥ졼�����λ */
        if((tend - tstart) > TIME_WAIT)
            return -1;
    }
}
/* 20070927 iseki_add end */


////////////////////////////////////////////////////////////////////////////////
// CMIP����������������Ω���ޥ��
////////////////////////////////////////////////////////////////////////////////
int cmipCreate()
{
    char buff[BUFFER_LEN];
    printf("***** Create Association *****\n");
    fflush(stdout);

    // input RDN
    if (tmgStringInput("Please set RDN name.\n> ",buff) == NULL)
        return -1;
    fflush(stdout);

    // convert RDN to ASN1::OCTET_STRING
    ASN1::AbstractData *ename = GetEntityName(buff);

    // send assoc create message
    g_user->TmgAscCrtReq(ename,TMG_CM_DEFAULT_ID_MASK);
    return 0;
}


////////////////////////////////////////////////////////////////////////////////
// CMIP���������������������ޥ��
////////////////////////////////////////////////////////////////////////////////
int cmipRelease()
{
    char buff[BUFFER_LEN];
    printf("***** Release Association *****\n");
    fflush(stdout);

    // input RDN
    if (tmgStringInput("Please  set RDN name.\n> ",buff) == NULL)
        return -1;

    // convert RDN to ASN1::OCTET_STRING
    ASN1::AbstractData *ename = GetEntityName(buff);

    // send assoc release message
    g_user->TmgAscRelReq(ename);

    return 0;
}


////////////////////////////////////////////////////////////////////////////////
// CMIP���ܡ��ȥ��ޥ��
////////////////////////////////////////////////////////////////////////////////
int cmipAbort()
{
    char buff[BUFFER_LEN];
    printf("***** Abort Association *****\n");
    fflush(stdout);

    // input RDN
    if (tmgStringInput("Please set RDN name.\n> ",buff) == NULL)
        return -1;

    // convert RDN to ASN1::OCTET_STRING
    ASN1::AbstractData *ename = GetEntityName(buff);

    // send assoc release message
    g_user->TmgAscAbtReq(ename);

    return 0;

}


/* iseki_start */
////////////////////////////////////////////////////////////////////////////////
// CMIP����������������Ω & �������ޥ��
////////////////////////////////////////////////////////////////////////////////
int cmipCreateRelease()
{
    int len;
    u_int number;
    char buff[BUFFER_LEN];
    char buff2[BUFFER_LEN];

    printf("***** Create & Release Association *****\n");
    fflush(stdout);

    if (tmgStringInput("Please set RDN name.\n> ", buff) == NULL)
        return -1;
    fflush(stdout);
    len = strlen(buff);
    if(len == 0)
        return -1;

    /* ���������������γ�Ω��������� */
    if(tmgStringInput("Please set number of times.\n> ", buff2) == NULL){
        return -1;
    }
    len = strlen(buff2);
    if(len == 0)
        return -1;
    number = atoi(buff2);
    if(number < 0)
        return -1;

    for(u_int i = 0; i < number; i++) {
        /* ����������������׵����� */
        g_user->TmgAscCrtReq(GetEntityName(buff),TMG_CM_DEFAULT_ID_MASK);
        s_assocFlg = ON; /* ASSOCIATION�ե饰ON */

        int rc = waitOp(ASSOCID); /* ����������������Ω�α����Ԥ� */
        if(rc == -1) { /* ����������������Ω���� */
            fprintf(stderr, "CreateRelease()___Association failed.\n");
            fflush(stderr);
#if DEBUG
            fprintf(stdout, "CreateRelease()___Association failed.\n");
            fflush(stdout);
#endif
            return -1;
        }
#if DEBUG
        fprintf(stdout, "CreateRelease()___num : %d, ___%d.\n", i+1, s_assocFlg);
        fflush(stdout);
#endif

        /* �������������������׵����� */
        g_user->TmgAscRelReq(GetEntityName(buff));
        ApplicationList::EventSleep(ASSOCTIME*100); /* �����Ԥ����� */
    }
    return 0;
}
/* iseki_add end */


////////////////////////////////////////////////////////////////////////////////
// CMIP M-GET���ޥ��
////////////////////////////////////////////////////////////////////////////////
#define MGET_TYPESELECT "[01]INTEGER (0��2147483647)\n[02]STRING (Max 32 charactors)\n[03]BOOLEAN (TRUE or FALSE)\n[04]STRING (More than 32 charactors)\n[05]TIME\nselect Get Type.\n> "

int cmipMget()
{
    int len, interval, optype;
    u_int number;
    char buff[BUFFER_LEN];
    char buff2[BUFFER_LEN];
    char buff3[BUFFER_LEN];
    char buff4[BUFFER_LEN];
    char buff5[BUFFER_LEN];

    printf("***** M-GET Request *****\n");
    fflush(stdout);

    // input RDN
    if (tmgStringInput("set RDN name.\n> ",buff) == NULL)
        return -1;

    // input Type
    if (tmgStringInput(MGET_TYPESELECT,buff2) == NULL){
        printf("\ncanceled\n") ;
        return -1;
    }

    // check Type
    int iType = atoi(buff2) ;
/* 20071019 error_test support start */
/*
    if( iType < 1 || iType > 5 ){
        printf("\ncanceled\n") ;
        return -1 ;
    }
*/
/* 20071019 error_test support end */

/* iseki_add start */
    // M-GET count
    if (tmgStringInput("set number of times.\n> ",buff3) == NULL) {
        printf("\ncanceled\n") ;
        return -1;
    }
    len = strlen(buff3);
    if(len == 0)
        return -1;
    number = atoi(buff3);
    if(number < 0)
        return -1;

    /* Ʊ��(Sync)����Ʊ����(Async)������ */
    if(tmgStringInput("Please set sending method.\n"
					 "(Sync: 0, Async: 1).\n> ",buff4) == NULL){
        return -1;
    }
    len = strlen(buff4);
    if(len == 0)
        return -1;

    optype = atoi(buff4);
    if(optype == 1){
        /* ��Ʊ�����Ǥ����硢�����ֳ֤����� */
        if(tmgStringInput("Please set interval(100 milli-second-scale interval).\n>"
                          ,buff5) == NULL){
            return -1;
        }
        len = strlen(buff5);
        if(len == 0)
            return -1;
        interval = atoi(buff5);
        if(interval < 0)
            return -1;
    }
    else if(optype > 1 || optype < 0)
        return -1;

    for(u_int i = 0; i < number; i++) {
        int ret;

        // convert RDN to ASN1::OCTET_STRING
        ASN1::AbstractData *ename = GetEntityName(buff);

        // edit M-GET request message
        A_GetArg * objGetArg = new A_GetArg ;

        objGetArg->set_baseManagedObjectClass().select_localForm() = 12345 ;
        objGetArg->set_baseManagedObjectInstance().select_nonSpecificForm(tmg_string(&buff[0])) ;
        A_XAtrId::iterator objAtrId = objGetArg->set_attributeIdList().insert() ;
        (*objAtrId).select_localForm() = iType ;

        // send M-GET request message
        g_user->TmgRequest( objGetArg, ename, g_user->getInvokeId() ) ;
        s_getFlg = ON;

#if DEBUG
        fprintf(stdout, "cmipGet()_TmgRequest___count:%d.\n", i+1);
        fflush(stdout);
#endif

        if(optype) { /* ASYNC */
            ApplicationList::EventSleep(interval*10); /* ��������Ĵ��(ñ��:msec) */
        }
        else { /* SYNC */

            ret = waitOp(GETID);
            if(ret == -1) {
                fprintf(stderr, "cmipGet()___M-GET failed.\n");
                fflush(stderr);
#if DEBUG
                fprintf(stdout, "cmipGet()___M-GET failed.\n");
                fflush(stdout);
#endif
                return -1;
            }
/* iseki_add end */
        }
    }
    return 0 ;
}


////////////////////////////////////////////////////////////////////////////////
// CMIP M-SET���ޥ��
////////////////////////////////////////////////////////////////////////////////
#define MSET_TYPESELECT "[01]INTEGER (0��2147483647)\n[02]STRING (Max 32 charactors)\n[03]BOOLEAN (TRUE or FALSE)\n[04]STRING (More than 32 charactors)\nselect Set Type.\n> "

int cmipMset()
{
    int len, optype, interval;
    u_int number;
    char buff[BUFFER_LEN];
    char buff2[BUFFER_LEN];
    char buff3[BUFFER_LEN];
    char buff4[BUFFER_LEN];
    char buff5[BUFFER_LEN];

    printf("***** M-SET Request *****\n");
    fflush(stdout);

    // input RDN
    if (tmgStringInput("set RDN name.\n> ",buff) == NULL)
        return -1;

    // input Type
    if (tmgStringInput(MSET_TYPESELECT,buff2) == NULL){
        printf("\ncanceled\n") ;
        return -1;
    }

    // check Type
    int iType = atoi(buff2) ;
/* 20071019 error_test support start */
/*
    if( iType < 1 || iType > 4 ){
        printf("\ncanceled\n") ;
        return -1 ;
    }
*/
/* 20071019 error_test support end */

    ASN1::AbstractData * objSetData ;
    int iValue ;

    switch(iType)
    {
    case 1 :
    // INTEGER
        if (tmgStringInput("input value.\n> ",buff2) == NULL){
            printf("\ncanceled\n") ;
            return -1;
        }
        iValue = atoi(buff2) ;
/* 20071019 error_test support start */
/*
        if( iValue < 0 ){
            printf("\ncanceled\n") ;
            return -1 ;
        }
*/
/* 20071019 error_test support end */
        objSetData = new ASN1::INTEGER(iValue) ;
        break ; 
    case 2 :
    // STRING
        if (tmgStringInput("input value.\n> ",buff2) == NULL){
            printf("\ncanceled\n") ;
            return -1;
        }
        if( strlen(buff2) > STRINGDATA_MAX ){
            printf("\ncanceled\n") ;
            return -1 ;
        }
        objSetData = new ASN1::PrintableString(tmg_string(buff2)) ;
        break ; 
    case 3 :
    // BOOLEAN
        if (tmgStringInput("input t or f.(t:TRUE/f:FALSE)\n> ",buff2) == NULL){
            printf("\ncanceled\n") ;
            return -1;
        }
        if( (tmg_string(buff2) != "t") && (tmg_string(buff2) != "f") ){
            printf("\ncanceled\n") ;
            return -1 ;
        }
        if( tmg_string(buff2) == "t" ){
            objSetData = new ASN1::BOOLEAN(true) ;
        } else {
            objSetData = new ASN1::BOOLEAN(false) ;
        }
        break ;
    case 4 :
    // STRING
        if (tmgStringInput("input value.\n> ",buff2) == NULL){
            printf("\ncanceled\n") ;
            return -1;
        }
        if( strlen(buff2) > STRINGDATALONG_MAX ){
            printf("\ncanceled\n") ;
            return -1 ;
        }
        objSetData = new ASN1::PrintableString(tmg_string(buff2)) ;
        break ; 
    default :
/* 20071019 error_test support start */
        objSetData = NULL ;
/* 20071019 error_test support end */
        break ; 
    }

/* 20070927 iseki_add start */
    /* M-SET���ޥ�ɲ�� */
    if(tmgStringInput("set number of times.\n> ", buff3) == NULL){
        return -1;
    }
    len = strlen(buff3);
    if(len == 0)
        return -1;
    number = atoi(buff3);
    if(number < 0)
        return -1;

    /* Ʊ��(Sync)����Ʊ����(Async)������ */
    if(tmgStringInput("Please set sending method.\n"
                     "(Sync: 0, Async: 1).\n> ", buff4) == NULL){
        return -1;
    }
    len = strlen(buff4);
    if(len == 0)
        return -1;

    optype = atoi(buff4);
    if(optype == 1){
        /* ��Ʊ�����Ǥ����硢�����ֳ֤����� */
        if(tmgStringInput("Please set interval(100 milli-second-scale interval).\n>"
                          , buff5) == NULL){
            return -1;
        }
        len = strlen(buff5);
        if(len == 0)
            return -1;
        interval = atoi(buff5);
        if(interval < 0)
            return -1;
    }
    else if(optype > 1 || optype < 0)
        return -1;

    for(u_int i = 0; i < number; i++) {
        int ret;

        // convert RDN to ASN1::OCTET_STRING
        ASN1::AbstractData *ename = GetEntityName(buff);

        // edit M-SET request message
        A_SetArg * objSetArg = new A_SetArg ;

        objSetArg->set_baseManagedObjectClass().select_localForm() = 12345 ;
        objSetArg->set_baseManagedObjectInstance().select_nonSpecificForm(tmg_string(&buff[0])) ;

        A_XMdfyLst::iterator setModify = objSetArg->set_modificationList().insert();
        (*setModify).set_modifyOperator() = TMG_MD_replace ;
        (*setModify).set_attributeId().select_localForm() = iType ;

/* 20071019 error_test support start */
//        (*setModify).set_attributeValue(*objSetData) ;
    if( objSetData ) (*setModify).set_attributeValue(*objSetData) ;
/* 20071019 error_test support end */

        // send M-SET request message
        g_user->TmgRequest( objSetArg, ename, g_user->getInvokeId() ) ;
        s_setFlg = ON;

#if DEBUG
        fprintf(stdout, "cmipSet()_TmgRequest___count:%d.\n", i+1);
        fflush(stdout);
#endif

        if(optype) { /* ASYNC */
            ApplicationList::EventSleep(interval*10); /* ��������Ĵ��(ñ��:msec) */
        }
        else { /* SYNC */
            s_setFlg = ON; /* M-SET�ե饰ON */

            ret = waitOp(SETID);
            if(ret == -1) {
                fprintf(stderr, "cmipSet()___M-SET failed.\n");
                fflush(stderr);
#if DEBUG
                fprintf(stdout, "cmipSet()___M-SET failed.\n");
                fflush(stdout);
#endif
            }
        }
    }
/* 20070927 iseki_add end */

    delete objSetData ;
    return 0 ;
}


////////////////////////////////////////////////////////////////////////////////
// CMIP M-ACTION���ޥ��
////////////////////////////////////////////////////////////////////////////////
int cmipMaction()
{
    char buff[BUFFER_LEN];

// 20071015 mochizuki added start
    char buff2[BUFFER_LEN];
// 20071015 mochizuki added end

    printf("***** M-ACTION Request *****\n");
    fflush(stdout);

    if (tmgStringInput("set RDN name.\n> ",buff) == NULL)
        return -1;

// 20071015 mochizuki added start
    if (tmgStringInput("select Action Mode.\n\t1.Reset ALL\n\t2.Get ALL\n\t3.Get Time\n> ",buff2) == NULL){
        printf("\ncanceled\n") ;
        return -1;
    }

    int iMode = atoi(buff2) ;
/* 20071019 error_test support start */
//    if( iMode < 1 || iMode > 3 ){
    if( iMode < 1 || ( iMode > 3 && iMode != 999 ) ){
/* 20071019 error_test support end */
        printf("\ncanceled\n") ;
        return -1;
    }
// 20071015 mochizuki added end

    // convert RDN to ASN1::OCTET_STRING
    ASN1::AbstractData *ename = GetEntityName(buff);

    // edit M-ACTION request message
    A_ActArg * objActArg = new A_ActArg ;

    objActArg->set_baseManagedObjectClass().select_localForm() = 12345 ;
    objActArg->set_baseManagedObjectInstance().select_nonSpecificForm(tmg_string(&buff[0])) ;
 
    A_ActInf * objActInfo = new A_ActInf() ;

// 20071015 mochizuki modified start
/*
    objActInfo->set_actionType().select_localForm() = 300 ;
    ASN1::AbstractData * objActInfoVal =  new ASN1::INTEGER(50) ;
    objActInfo->set_actionArgument(*objActInfoVal) ;

    objActArg->set_actionInfo(*objActInfo) ;

    g_user->TmgRequest( objActArg, ename, g_user->getInvokeId() ) ;
*/

    objActInfo->set_actionType().select_localForm() = 100 ;

    ASN1::AbstractData * objActInfoVal = NULL ;
    switch( iMode ){
    case 1 :
        objActInfoVal =  new ASN1::PrintableString(tmg_string(STRING_ACTION_ARG001)) ;
        break ;
    case 2 :
        objActInfoVal =  new ASN1::PrintableString(tmg_string(STRING_ACTION_ARG002)) ;
        break ;
    case 3 :
        objActInfoVal =  new ASN1::PrintableString(tmg_string(STRING_ACTION_ARG003)) ;
        break ;
    default :
/* 20071019 error_test support start */
        objActInfoVal =  new ASN1::PrintableString(tmg_string("other")) ;
/* 20071019 error_test support end */
        break ; 
    }
    objActInfo->set_actionArgument(*objActInfoVal) ;

    objActArg->set_actionInfo(*objActInfo) ;

    int sendInvId = g_user->getInvokeId() ;

    if( iMode == 1 ){
        g_user->TmgRequest( objActArg, ename, sendInvId, TMG_NO_CONFIRMED_REQUEST) ;
    } else {
        if( iMode == 2 ){
            g_ACTIONinvokeId = sendInvId ;
        }
        g_user->TmgRequest( objActArg, ename, sendInvId ) ;
    }
// 20071015 mochizuki modified end

    delete objActInfo ;
    delete objActInfoVal ;

    return 0 ;

}


////////////////////////////////////////////////////////////////////////////////
// CMIP���������������������ޥ��
////////////////////////////////////////////////////////////////////////////////
int cmipMEventReport()
{
    int len;
    u_int number, interval;
    char buff[BUFFER_LEN];
    char buff2[BUFFER_LEN];
    char buff3[BUFFER_LEN];
    char buff4[BUFFER_LEN];
    char buffmessage[BUFFER_LEN];
    printf("***** M-EVENT-REPORT Request *****\n");
    fflush(stdout);

    // input My RDN
    if (tmgStringInput("set My RDN name.\n> ",buff) == NULL)
        return -1;

    // select Destination RDN
    PrintAscList(1) ;
    if (tmgStringInput("Select Destination No.\n> ",buff2) == NULL)
        return -1 ;

    int iSelect = atoi(buff2) ;
    if( iSelect < 1 || iSelect > (int)g_AscList.size() ){
        return -1 ;
    }

/* iseki_add start */
    if (tmgStringInput("Input Message.\n> ",buffmessage) == NULL)
        return -1 ;

    /* M-EVENTREPORT���ޥ�ɲ�� */
    if(tmgStringInput("Please set number of times.\n> ",buff3) == NULL){
        return -1;
    }
    len = strlen(buff3);
    if(len == 0)
        return -1;
    number = atoi(buff3);
    if(number < 0)
        return -1;

    if(number != 1) { /* �����֤������1�ξ�硢�����ֳ֤����� */
        /* M-EVENTREPORT���ޥ�������ֳ� */
        if(tmgStringInput("Please set interval(100 milli-second-scale interval).\n> "
	     	    , buff4) == NULL){
            return -1;
        }
        len = strlen(buff4);
        if(len == 0)
            return -1;
        interval = atoi(buff4);
        if(interval < 0)
            return -1;
    }

    for(u_int i = 0; i < number; i++) {

        ASN1::AbstractData *ename = GetEntityName( g_AscList[iSelect-1].c_str() ) ; 

        // edit M-EVENT-REPORT request message
        A_EvtRepArg * objEvtRepArg = new A_EvtRepArg ;

        objEvtRepArg->set_managedObjectClass().select_localForm() = 12345 ;
        objEvtRepArg->set_managedObjectInstance().select_nonSpecificForm(tmg_string(buff)) ;

        struct timeval tvNow ;
        gettimeofday( &tvNow , NULL ) ;
        struct tm * tmNow = localtime( &tvNow.tv_sec ) ;
        A_EventTime objEvtTime( tmNow->tm_year+1900, 1, 1 ) ;
        objEvtRepArg->set_eventTime( objEvtTime ) ;

        objEvtRepArg->set_eventType().select_localForm() = 1000 ;

        ASN1::AbstractData * objString = new ASN1::PrintableString(tmg_string(buffmessage)) ;

        objEvtRepArg->set_eventInfo( *objString ) ;

        // send M-EVENT-REPORT request message
        g_user->TmgRequest( objEvtRepArg, ename, g_user->getInvokeId(),TMG_NO_CONFIRMED_REQUEST ) ;

        if(number != 1)
            ApplicationList::EventSleep(interval*10); /* �����δֳ��Ԥ�(ñ��:msec) */
        delete objString ;
    }
/* iseki_add end */

    return 0 ;

}


////////////////////////////////////////////////////////////////////////////////
// �����ǡ�������
////////////////////////////////////////////////////////////////////////////////
#define LOCALDATA_TYPESELECT "[01]INTEGER (0��2147483647)\n[02]STRING (Max 32 charactors)\n[03]BOOLEAN (TRUE or FALSE)\n[04]STRING (More than 32 charactors)\n[05]Number of characters by LinkedReply\nselect Set Type.\n> "
int setLocalData()
{
    char buff[BUFFER_LEN];
    char buff2[BUFFER_LEN];
    int iValue ;
    printf("***** Set Local Data *****\n");
    fflush(stdout);

    // input Type
    if (tmgStringInput(LOCALDATA_TYPESELECT,buff) == NULL){
        printf("\ncanceled\n") ;
        return -1;
    }

    // check Type
    int iType = atoi(buff) ;
    if( iType < 1 || iType > 5 ){
        printf("\ncanceled\n") ;
        return -1 ;
    }

    switch(iType)
    {
    case 1 :
    // INTEGER
        if (tmgStringInput("input value.\n> ",buff2) == NULL){
            printf("\ncanceled\n") ;
            return -1;
        }
        iValue = atoi(buff2) ;
        if( iValue < 0 ){
            printf("\ncanceled\n") ;
            return -1 ;
        }
        g_iData = iValue ;
        break ; 
    case 4 :
    // STRING LONG
        if (tmgStringInput("input \"value\" or \"filepath\"(v:value/f:filepath).\n> ",buff2) == NULL){
            printf("\ncanceled\n") ;
            return -1;
        }
        if( (tmg_string(buff2) != "v") && (tmg_string(buff2) != "f") ){
            printf("\ncanceled\n") ;
            return -1 ;
        }
        if( tmg_string(buff2) == "f" ){
            // set filepath
            if (tmgStringInput("input filepath.\n> ",buff2) == NULL){
                printf("\ncanceled\n") ;
                return -1;
            }
            struct stat objStat ;
            if( stat( buff2, &objStat ) == -1 ){
                printf("\nfile is not exist\n") ;
                return -1;
            }
            if( !S_ISREG(objStat.st_mode) ){
                printf("\npath is not file\n") ;
                return -1;
            }
            g_LinkedReplyDataPath.assign(buff2) ;
            delete [] g_strDatalong ;
            g_strDatalong = NULL ;
            break ;
        }
        // if "v", same process case2
        
    case 2 :
    // STRING
        if (tmgStringInput("input value.\n> ",buff2) == NULL){
            printf("\ncanceled\n") ;
            return -1;
        }
        if( iType == 2 ){
            if( strlen(buff2) > STRINGDATA_MAX ){
                printf("\ncanceled\n") ;
                return -1 ;
            }
            delete [] g_strData ;
            g_strData = new char[strlen(buff2)+1] ;
            strcpy( g_strData, buff2 ) ;
        } else {
            if( strlen(buff2) > STRINGDATALONG_MAX ){
                printf("\ncanceled\n") ;
                return -1 ;
            }
            g_LinkedReplyDataPath.remove() ;
            delete [] g_strDatalong ;
            g_strDatalong = new char[strlen(buff2)+1] ;
            strcpy( g_strDatalong, buff2 ) ;
        }
        break ; 
    case 3 :
    // BOOLEAN
        if (tmgStringInput("input t or f.(t:TRUE/f:FALSE)\n> ",buff2) == NULL){
            printf("\ncanceled\n") ;
            return -1;
        }
        if( (tmg_string(buff2) != "t") && (tmg_string(buff2) != "f") ){
            printf("\ncanceled\n") ;
            return -1 ;
        }
        if( tmg_string(buff2) == "t" ){
            g_bData = true ;
        } else {
            g_bData = false ;
        }
        break ;
    case 5:
    // Number of characters by LinkedReply
       if (tmgStringInput("input Number\n> ",buff2) == NULL){
            printf("\ncanceled\n") ;
            return -1;
        }
        iValue = atoi(buff2) ;
        if( iValue < 0 ){
            printf("\ncanceled\n") ;
            return -1 ;
        }
        LINKEDREPLY_UNIT = iValue ;
        break ;
    default :
        break ; 
    }

    return 0 ;

}


////////////////////////////////////////////////////////////////////////////////
// �桼�������ޥ�ɥᥤ�����
////////////////////////////////////////////////////////////////////////////////
int userCmdProcess(char* buf)
{
    int ret;

    if(strcmp(buf, "CRT") == 0) { // CMIP ����������������Ω
        ret = cmipCreate();
        if(ret == -1) {
            fprintf(stderr, "Input Error.\n");
            fflush(stderr);
        }
        return 0;
    }
    else if(strcmp(buf, "REL") == 0) { // CMIP ������������������
        ret = cmipRelease();
        if(ret == -1) {
            fprintf(stderr, "Input Error.\n");
            fflush(stderr);
        }
        return 0;
    }
    else if(strcmp(buf, "ABT") == 0) { // CMIP ���ܡ���
        ret = cmipAbort();
        if(ret == -1) {
            fprintf(stderr, "Input Error.\n");
            fflush(stderr);
        }
        return 0;
    }
    if(strcmp(buf, "CREL") == 0) { // CMIP ����������������Ω & ����
        ret = cmipCreateRelease();
        if(ret == -1) {
            fprintf(stdout, "Input Error.\n");
            fflush(stdout);
        }
        return 0;
    }
    else if(strcmp(buf, "G") == 0) { // CMIP M-GET�׵�
        ret = cmipMget();
        if(ret == -1) {
            fprintf(stderr, "Input Error.\n");
            fflush(stderr);
        }
        return 0;
    }
    else if(strcmp(buf, "S") == 0) { // CMIP M-SET�׵�
        ret = cmipMset();
        if(ret == -1) {
            fprintf(stderr, "Input Error.\n");
            fflush(stderr);
        }
        return 0;
    }
    else if(strcmp(buf, "A") == 0) { // CMIP M-ACTION�׵�
        ret = cmipMaction();
        if(ret == -1) {
            fprintf(stderr, "Input Error.\n");
            fflush(stderr);
        }
        return 0;
    }
    else if(strcmp(buf, "E") == 0) { // CMIP M-EVENT-REPORT����
        ret = cmipMEventReport();
        if(ret == -1) {
            fprintf(stderr, "Input Error.\n");
            fflush(stderr);
        }
        return 0;
    }
    else if(strcmp(buf, "L") == 0) { // �����ǡ���ɽ��
        printIData() ;
        printStrData(STRINGDATA_PTR) ;
        printBData() ;
        printStrData(STRINGDATALONG_PTR) ;
        printf("LINKEDREPLY FILE PATH[%s]\n",g_LinkedReplyDataPath.c_str()) ;
        printf("Number of characters by LinkedReply[%d]\n",LINKEDREPLY_UNIT) ;
        return 0;
    }
    else if(strcmp(buf, "SL") == 0) { // �����ǡ�������
        ret = setLocalData();
        if(ret == -1) {
            fprintf(stderr, "Input Error.\n");
            fflush(stderr);
        }
        return 0;
    }
    else if(strcmp(buf, "Q") == 0) { // USER���ޥ�ɤ�QUIT
        return 1;
    }
    else { // ���ޥ�ɰ���
        printf("\n");
        printf("   CRT : Create CMIP Association\n");
        printf("   REL : Release CMIP Association\n");
        printf("   ABT : Abort   CMIP Association\n");
        printf("  CREL : Create & Release CMIP Association\n");
        printf("     G : M-GET Request\n");
        printf("     S : M-SET Request\n");
        printf("     A : M-ACTION Request\n");
        printf("     E : M-EVENT-REPORT Request\n");
        printf("     L : display local data value\n");
        printf("    SL : set local data value\n");
        printf("     Q : Quit\n");
        printf("\n");
        return 0;
    }
}
