// $Id: cmUserImpl.h,v 1.4 2007-09-10 16:21:37+09 tmn Exp $
// $Log: cmUserImpl.h,v $
// Revision 1.4  2007-09-10 16:21:37+09  tmn
// TMG_ERRORconfirm implement
//
// Revision 1.3  2007/09/05 09:24:06  tmn
// A-RELEASE.INDICATION notify
//
// Revision 1.2  2007/08/17 02:49:25  tmn
// abort command support
//
// Revision 1.1  2007/08/15 02:13:13  tmn
// Initial revision
//
#ifndef CMUSERIMPL_H
#define CMUSERIMPL_H

#include "tmgCmUser.h"

class TmgCmUserImpl : public TmgOpUser
{
public:
    TmgCmUserImpl();
    virtual ~TmgCmUserImpl();
/* iseki_add */
    void TmgAscCrtCnf(TmgCmAscEnumState, int, int);
    void TMG_GETconfirm(ASN1::AbstractData*, int, int, int);
    void TMG_GETindication(ASN1::AbstractData*, ASN1::AbstractData*, int, int);

    void TMG_SETconfirm(ASN1::AbstractData*, int, int, int);
    void TMG_SETindication(ASN1::AbstractData*, ASN1::AbstractData*, int, int, int);

    void TMG_ACTIONconfirm(ASN1::AbstractData*, int, int, int);
    void TMG_ACTIONindication(ASN1::AbstractData*, ASN1::AbstractData*, int, int, int);

    void TMG_EVENTindication(ASN1::AbstractData*, ASN1::AbstractData*, int, int, int);
    void TmgAscInd(int caId, TmgApcPaddr *pa, ASN1::AbstractData *cxnName,
                   TmgApcOct *cldApt, TmgApcOct *cldAeq, int cldApi, int cldAei,
                   TmgApcOct *clgApt, TmgApcOct *clgAeq, int clgApi, int clgAei,
                   A_CMIPUserInfo *uInfo, TmgApcOct *rspApt, int cid );

    void TMG_NULLconfirm(int, int);

    int getInvokeId() 
    {
        if( invoke_count < 0x7FFFFFFF ){
            invoke_count++ ;
        } else {
            invoke_count = 1 ;
        }
        return invoke_count ; 
    }

    void TMG_ASSOC_ERRORindication(ASN1::AbstractData*, int);
    void TmgAscRelInd(ASN1::AbstractData*, int);

    void TMG_ERRORindication(ASN1::AbstractData *arg, int invoke, int cid) ;
    void TMG_ERRORconfirm(ASN1::AbstractData *arg, int invoke, int cid) ;


private:
    int  invoke_count ;
/* 20071019 error_test support start */
    void sendInvokeError( const A_ErrorStatus* errStatus, const ASN1::AbstractData* errParam, ASN1::AbstractData* name, int invoke ) ;
/* 20071019 error_test support end */

};

#endif /* CMUSERIMPL_H */
