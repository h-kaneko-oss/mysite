// $Id: nmftest.cc,v 1.1 2007/08/15 02:09:55 tmn Exp $
// $Log: nmftest.cc,v $
// Revision 1.1  2007/08/15 02:09:55  tmn
// Initial revision
//
// vi:ts=8:sw=4
//
//	program for alltypes sample
//
#include "tmgMib.h"

// Standard Console and Socket Console ----------------------------
#include "tmgCoSockMib.h"   /* Socket Console class */
#include "tmgCoEventMib.h"  /* Standard Console class */


// ----------------------------------------------------------------

class TestApp : public ApplicationList {
public:
    TestApp();
    int		ThreadInitializeOk();
    void	Initialize();
};


// Help Message ---------------------------------------------------
static void usage(int argc,char** argv)
{
    fprintf(stderr,"%s [options]\n",argv[0]);
    fprintf(stderr,"\
options:\n\
  -help			(Display this message)\n\
  -sockcons		(Use socket console)\n");

    tmgExpandOptionFile(argc,argv,"AP1");
    TmgMIBinitialize(argc,argv,NULL);
    TmgSockConsMIB sockCons;
    sockCons.Init(argc,argv);
}

// ----------------------------------------------------------------

int	main(int argc, char* argv[])
{
    int consoleType = TMG_STD_CONS;	// TMG_STD_CONS: Use Standard Console, 
					// TMG_SOCK_CONS: Use Socket Console

// -help�����뤫����
    if (tmgCmdLineOptionChk("-help",argc,argv)){
	usage(argc,argv);
	exit(1);
    }

// ���ץ����β��� --------------------------------------
    // ���ץ����ե������Ÿ��
    if (tmgExpandOptionFile(argc,argv,"AP1") < 0)
	exit(2);

    // ñ�����ץ����
    if (tmgCmdLineOption1("-sockcons",argc,argv)){
	consoleType = TMG_SOCK_CONS;
	printf("sockcons: on\n");
    }

// Event Applications --------------------------------------
    YataEventHandler eventhandler;

// Initialize MIB interface --------------------------------------
    TmgOpUser *user = new TmgOpUser;
    if (TmgMIBinitialize(argc,argv,user) < 0)
	exit(1);

// User Applications --------------------------------------
    if(consoleType == TMG_SOCK_CONS){	// Use Socket Console
	TmgSockCons *sockCons = new TmgSockConsMIB;
	if (sockCons->Init(argc,argv) < 0) {
	    exit(1);
	}
    }
    else if(consoleType == TMG_STD_CONS){	// Use Standard Console
	TmgConsEvent *consEvent = new TmgConsEventMIB;
	if(consEvent->Init(argc,argv) < 0){
	    exit(1);
	}
    }

// ----------------------------------------------------------------
    new TestApp;

// Start Main Loop -----------------------------------------------------

    eventhandler.loop();

    return	0;
}


// ----------------------------------------------------------------

TestApp::TestApp()
{
    SetInitializePriority(100);
}

int TestApp::ThreadInitializeOk()
{
    return 1;
}

#define PR_INT(x)	printf(#x " : %d\n",x);
#define PR_STR(x)	printf(#x " : %s\n",x);
#define PR_HEX(x)	printf(#x " : %x\n",x);
#define PR_NON(x)	printf(#x "\n"); x;
#define PR_NONN(x)	printf(#x "\n"); x
#define PR_NONE(x)	x printf(#x "\n");
#define PR_ANY(x,f)	printf(#x " : " #f "\n",x);
#define	PR_LF		printf("\n");
#define PR(x)		printf(#x "\n");

void	TestApp::Initialize()
{
// Test NMF API
    int i;
    {
    PR(---- Create DN from LocalRoot ----)
    PR_NON(A_DN dn)
    PR_INT(dn.size())
    PR_INT(dn.MOtoDN(A_TOP::localRootMO()))
    PR_NON(dn[3][0].ref_attributeValue().memberGet(1)->valSetStr("ALL2"))
    PR_STR(dn.asValueNotation().data())
    PR_INT(dn.size())
    PR_LF

    PR(---- Print DN using iterator ----)
    PR_NONN({)
    PR_NON(A_DN::iterator its = dn.begin())
    PR_NON(A_DN::iterator ite = dn.end())
    PR_INT(ite - its)
    PR_NONN(while (its < ite){)
	PR_NON(const ASN1::OBJECT_IDENTIFIER &type = (*its).begin()[0].get_attributeType())
	PR_STR(type.valGetStr())
	PR_NONN(for (i = 0 ; i < type.levels() ; i++){)
	    PR_ANY(type[i],"%ld")
	PR_NONE(})
	PR_NON(its++)
    PR_NONE(})
    PR_NONE(})
    PR_LF

    PR(---- DN front back ----)
    PR_STR(dn.front()[0].get_attributeType().valGetStr())
    PR_STR(dn.back()[0].get_attributeType().valGetStr())
    PR_LF

    PR(---- SEQUENCE OF Generic API ----)
    PR_NON(ASN1::SEQUENCE_OF* seqof = &dn)
    PR_NONN({)
    PR_INT(seqof->size());
    PR_NON(ASN1::SEQUENCE_OF::iterator its = seqof->begin())
    PR_NON(ASN1::SEQUENCE_OF::iterator ite = seqof->end())
    PR_INT(ite - its)
    PR_NONN(while (its < ite){)
	PR_NON(ASN1::SET_OF& rdn = (ASN1::SET_OF&)(*its));
	PR_NON(ASN1::SEQUENCE& ava = (ASN1::SEQUENCE&)rdn[0])
	PR_STR(ava.get("attributeType").valGetStr())
	PR_NON(its++)
    PR_NONE(})
    PR_NONE(})
    PR_LF
    PR_NONN({)
	PR_NON(ASN1::SET_OF& rdn = (ASN1::SET_OF&)(seqof->front()));
	PR_NON(ASN1::SEQUENCE& ava1 = (ASN1::SEQUENCE&)rdn[0])
	PR_STR(ava1.get(0).valGetStr())
	PR_NON(ASN1::SET_OF& rdn2 = (ASN1::SET_OF&)(seqof->back()));
	PR_NON(ASN1::SEQUENCE& ava = (ASN1::SEQUENCE&)rdn2[0])
	PR_STR(ava.get(0).valGetStr())
	PR_LF

	PR(---- CHOICE Generic API ----)
	PR_NON(ASN1::CHOICE& mid = (ASN1::CHOICE&)ava.get("attributeValue"))
	PR_INT(mid.isSelected("numericName"))
	PR_INT(mid.isSelected("pString"))
	PR_STR(mid.get("pString").valGetStr())
	PR_STR(mid.ref("pString").valGetStr())
	PR_NON(mid.select("numericName").valSetInt(10))
	PR_INT(mid.get(0).valGetInt())
	PR_INT(mid.ref(0).valGetInt())
	PR_NON(ATTOP* gs = new A_GraphicString)
	PR_NON(gs->valSetStr("abcdef"))
	PR_STR(mid.select("pString",*gs).valGetStr())
	PR_NON(mid.select(0).valSetInt(20))
	PR_INT(mid.get(0).valGetInt())
	PR_STR(mid.select(1,*gs).valGetStr())
	PR_STR(mid.get(1).valGetStr())
	PR_STR(mid.ref(1).valGetStr())
	PR_LF

	PR(---- SEQUENCE Generic API ----)
	PR_NON(ava.ref("attributeType").valSetStr("attr-int"))
	PR_STR(ava.ref(0).valGetStr())
	PR_INT(ava.isPresent("attributeType"))
	PR_NON(ava.omit("attributeType"))
	PR_INT(ava.isPresent(0))
	PR_NON(ava.set("attributeType").valSetStr("attr-int"))
	PR_STR(ava.get("attributeType").valGetStr())
	PR_NON(ava.omit(0))
	PR_NON(ava.set(0).valSetStr("attr-int"))
	PR_STR(ava.get(0).valGetStr())
	PR_NON(A_OBJECT_IDENTIFIER* oid = new A_OBJECT_IDENTIFIER);
	PR_NON(oid->valSetStr("attr-int"));
	PR_STR(ava.set("attributeType",*oid).valGetStr())
	PR_STR(ava.set(0,*oid).valGetStr())
    PR_NONE(})
    PR_LF

    PR(---- DN resize ----)
    PR_NON(dn.resize(3))
    PR_NONN(for (i = 0 ; i < dn.size() ; i++){)
	PR_STR(dn[i][0].get_attributeValue().valGetStr())
    PR_NONE(})
    PR_LF

    PR(---- OCTET STRING ----)
    PR_NON(A_RDistName rdn)
    PR_NON(A_AtrVAsrt ava)
    PR_NON(ava.set_attributeType().valSetStr("attr-octet"))
    PR_NON(ASN1::OCTET_STRING& oct = (ASN1::OCTET_STRING&)ava.set_attributeValue())
    PR_NON(oct.resize(10,'A'))
    PR_NON(rdn.insert(ava))
    PR_NON(dn.push_front(rdn))
    PR_STR(dn.front()[0].get_attributeType().valGetStr());
    PR_STR(dn.asValueNotation().data())
    PR_LF

    PR_NON((ASN1::OCTET_STRING&)(rdn[0].ref_attributeValue()) = "BCDEF")
    PR_NON(dn.push_back(rdn))
    PR_STR(dn.back()[0].get_attributeType().valGetStr());
    PR_STR(dn.asValueNotation().data())
    PR_LF

    PR_NON((ASN1::OCTET_STRING&)(rdn.begin()[0].ref_attributeValue()) = "GHIJK")
    PR_NON(dn.insert(dn.begin()+1,2,rdn))
    PR_STR(dn.asValueNotation().data())
    PR_LF

    PR_NONN(for (i = 0 ; i < dn.size() ; i++){)
	PR_STR(dn[i][0].get_attributeValue().valGetStr())
    PR_NONE(})
    PR_LF

    PR_NON(dn.pop_front())
    PR_STR(dn.asValueNotation().data())
    PR_NONN(for (i = 0 ; i < dn.size() ; i++){)
	PR_STR(dn[i][0].get_attributeValue().valGetStr())
    PR_NONE(})
    PR_LF

    PR_NON(dn.pop_back())
    PR_NONN(for (i = 0 ; i < dn.size() ; i++){)
	PR_STR(dn[i][0].get_attributeValue().valGetStr())
    PR_NONE(})
    }

    PR_LF
    PR_LF

    {
    PR_NON(A_RDistName rdn)
    PR_INT(rdn.size())
    PR_NON(A_AtrVAsrt ava)
    PR_NON(ava.set_attributeType().valSetStr("attr-int"))
    PR_NON(ava.set_attributeValue().valSetInt(100))
    PR_NON(rdn.insert(ava))
    PR_INT(rdn.size())
    PR_NON(ava.set_attributeValue().valSetInt(200))
    PR_NON(rdn.insert(ava))
    PR_INT(rdn.size())
    PR_NON(ava.set_attributeValue().valSetInt(300))
    PR_NON(rdn.insert(ava))
    PR_INT(rdn.size())
    PR_NON(A_RDistName::iterator its = rdn.begin())
    PR_NON(A_RDistName::iterator ite = rdn.end())
    PR_INT(ite - its)
    PR_NONN(while (its < ite){)
	PR_INT((*its).get_attributeValue().valGetInt())
	PR_NON(its++)
    PR_NONE(})
    PR_LF

    PR_NON(A_RDistName rdn2(rdn))
    PR_NONN(for (i = 0 ; i < rdn2.size() ; i++){)
	PR_INT(rdn2[i].get_attributeValue().valGetInt())
    PR_NONE(})
    PR_NON(ava.set_attributeValue().valSetInt(400))
    PR_INT((*rdn2.insert(rdn2.end(),ava)).get_attributeValue().valGetInt())
    PR_NONN(for (i = 0 ; i < rdn2.size() ; i++){)
	PR_INT(rdn2[i].get_attributeValue().valGetInt())
    PR_NONE(})
    PR_LF

    PR_NON(ava.set_attributeValue().valSetInt(500))
    PR_INT(rdn2.insert(rdn2.begin()+3,ava)[0].get_attributeValue().valGetInt())
    PR_NONN(for (i = 0 ; i < rdn2.size() ; i++){)
	PR_INT(rdn2[i].get_attributeValue().valGetInt())
    PR_NONE(})
    PR_LF

    PR_NON(A_RDistName rdn3 = rdn)
    PR_NONN(for (i = 0 ; i < rdn3.size() ; i++){)
	PR_INT(rdn3[i].get_attributeValue().valGetInt())
    PR_NONE(})
    PR_LF

    PR_NON(its = rdn2.begin())
    //PR_NON(rdn3.insert(rdn3.begin()+1,its+2,its+5))
    //PR_NONN(for (i = 0 ; i < rdn3.size() ; i++){)
//	PR_INT(rdn3[i].get_attributeValue().valGetInt())
 //   PR_NONE(})

    PR_NON(rdn3.insert(its,its+2))
    PR_NONN(for (i = 0 ; i < rdn3.size() ; i++){)
	PR_INT(rdn3[i].get_attributeValue().valGetInt())
    PR_NONE(})
    PR_NON(its = rdn3.begin())
    PR_NON(rdn3.erase(its))
    PR_NONN(for (i = 0 ; i < rdn3.size() ; i++){)
	PR_INT(rdn3[i].get_attributeValue().valGetInt())
    PR_NONE(})
    PR_NON(rdn3.erase(its+1,its+3))
    PR_NONN(for (i = 0 ; i < rdn3.size() ; i++){)
	PR_INT(rdn3[i].get_attributeValue().valGetInt())
    PR_NONE(})
    PR_NON(ava.set_attributeValue().valSetInt(300))
    PR_NON(rdn3.erase(ava))
    PR_NONN(for (i = 0 ; i < rdn3.size() ; i++){)
	PR_INT(rdn3[i].get_attributeValue().valGetInt())
    PR_NONE(})
    PR_NON(rdn2.swap(rdn3))
    PR_NONN(for (i = 0 ; i < rdn2.size() ; i++){)
	PR_INT(rdn2[i].get_attributeValue().valGetInt())
    PR_NONE(})
    PR_NONN(for (i = 0 ; i < rdn3.size() ; i++){)
	PR_INT(rdn3[i].get_attributeValue().valGetInt())
    PR_NONE(})
    PR_NON(A_AtrVAsrt& x = rdn3.push_back())
    PR_NON(x.set_attributeType().valSetStr("attr-int"))
    PR_NON(x.set_attributeValue().valSetInt(150))
    PR_NONN(for (i = 0 ; i < rdn3.size() ; i++){)
	PR_INT(rdn3[i].get_attributeValue().valGetInt())
    PR_NONE(})
    }

    PR_LF
    PR_LF

    PR_NONN(try {)
    PR_NON(A_ActInf ai1)
    PR_NON(TmgAtPrint(&ai1))
    PR_STR(ai1.asValueNotation().data())
    //PR_NON(tmg_string vn((const char *)"{iso(1) member-body(2) 123 2 1}"))
    //PR_NON(A_ActInf::actionType::value_type::globalForm::value_type aidid(tmg_string((const char *)"{iso(1) member-body(2) 123 2 1}")))
    PR_NON(A_ActInf::actionType::value_type::globalForm::value_type aidid("{iso(1) member-body(2) 123 2 1}"))
    //PR_NON(A_ActInf::actionType::value_type::globalForm::value_type aidid)
    //PR_NON(aidid.valSetStr("action1"))
    PR_NON(A_ActInf::actionType::value_type aid(A_ActInf::actionType::value_type::globalForm::id,aidid))
    PR_NON(A_ActInf ai2(aid))
    PR_NON(TmgAtPrint(&ai2))
    PR_NON(A_ActInf ai3(aid,NULL))
    PR_NON(TmgAtPrint(&ai3))
    PR_STR(ai3.asValueNotation().data())
    PR_INT(ai3.opt_actionType())
    PR_INT(ai3.opt_actionArgument())
    PR_INT(ai3.actionType_isPresent())
    PR_INT(ai3.actionArgument_isPresent())
    PR_NON(ai3.set_actionArgument())
    PR_INT(ai3.actionArgument_isPresent())
    PR_NON(ai3.omit_actionArgument())
    PR_INT(ai3.actionArgument_isPresent())
    PR_INT(aid.globalForm_isSelected())
    PR_INT(aid.localForm_isSelected())
    PR_INT(aid.currentSelection())
    PR_INT(aid.isSelected(A_EventTypeId::unknownSelection_))
    PR_INT(aid.isSelected(A_EventTypeId::unselected_))
    PR_INT(aid.isSelected(A_EventTypeId::globalForm::id))
    PR_INT(aid.isSelected(A_EventTypeId::localForm::id))
    PR_INT(aid.isUnknownSelection())
    PR_NON(aid.select_localForm() = 123)
    PR_INT(aid.localForm_isSelected())
    PR_INT(aid.get_localForm().valGetInt())
    PR_NON(aid.ref_localForm() += 100)
    PR_INT(aid.get_localForm().valGetInt())
    PR_NON(ASN1::INTEGER bbb(456))
    PR_INT(aid.select_localForm(bbb).valGetInt())
    }
    PR_NONE(catch (ASN1::ElementMissing ex) {)
	PR_STR(ex.what())
    PR_NONN(})

    PR_NONN(try {)
	PR_NON(A_ModifyOperator md)
	PR_NON(md.set_add())
	PR_INT(md.is_replace())
	PR_INT(md.is_add())
	PR_INT(md.is_remove())
	PR_INT(md.is_setToDefault())
	PR_NON(A_ModifyOperator md2(md))
	PR_INT((int)md2)
	PR_NON(A_ModifyOperator md3(A_ModifyOperator::remove))
	PR_INT((int)md3)
	PR_STR(md.asValueNotation().data())

	PR_NON(A_ErrorStatus es)
	PR_NON(es.set_noSuchAction())
	PR_INT(es.is_noSuchAction())
	PR_INT(es.is_processingFailure())
	PR_NON(A_ErrorStatus es2(es))
	PR_INT(es2.asInt())
	PR_NON(A_ErrorStatus es3(A_ErrorStatus::noSuchArgument))
	PR_INT(es3.asInt())
	PR_NON(A_ErrorStatus es4 = A_ErrorStatus::accessDenied)
	PR_INT(es4.asInt())
	PR_INT((A_ErrorStatus::NamedNumber)es4)
	PR_STR(es.asValueNotation().data())

	PR_NON(A_FunctionalUnits fu)
	PR_NON(fu.resize(5))
	PR_NON(fu.set_filter())
	PR_NON(fu.set_extendedService())
	PR_INT(fu.is_multipleObjectSelection())
	PR_INT(fu.is_filter())
	PR_NON(fu.reset_filter())
	PR_STR(fu.getOctets().data())
	PR_NON(A_FunctionalUnits::iterator its = fu.begin())
	PR_NON(A_FunctionalUnits::iterator ite = fu.end())
	PR_NONN(while (its < ite){)
	    PR_INT((bool)*its++);
	PR_NONE(})
	PR_NON(*(fu.begin()+1) = true)
	PR_INT(fu.is_filter())
	PR_NONN(for (i = 0 ; i < fu.size() ; i++){)
	    PR_INT((bool)fu[i]);
	PR_NONE(})
	PR_NON(A_FunctionalUnits fu2(fu))
	PR_NON(fu2.insert(fu2.begin(),2,true))
	PR_INT(fu2.size())
	PR_STR(fu2.getOctets().data())
	PR_INT((bool)*fu2.insert(fu2.begin()+1,false))
	PR_INT(fu2.size())
	PR_NON(fu2.insert(fu2.end(),fu.begin(),fu.begin()+2))
	PR_INT(fu2.size())
	PR_STR(fu2.getOctets().data())
	PR_NON(fu2.erase(fu2.begin(),fu2.begin()+3))
	PR_INT(fu2.size())
	PR_STR(fu2.getOctets().data())
	PR_NON(fu2.erase(fu2.begin()+1))
	PR_INT(fu2.size())
	PR_NON(fu2.setFromOctets(tmg_string("A3E")))
	PR_STR(fu2.getOctets().data())
	PR_NON(fu2.swap(fu))
	PR_STR(fu.getOctets().data())
	PR_STR(fu2.getOctets().data())
	PR_STR(fu.asValueNotation().data())

	PR_NON(A_OctetAligned oc)
	PR_INT(oc.size())
	PR_NON(oc.resize(10))
	PR_INT(oc.size())
	PR_NON(oc[3] = 43)
	PR_NON(oc[7] = 47)
	PR_NONN(for (i = 0 ; i < oc.size() ; i++){)
	    PR_INT(oc[i])
	PR_NONE(})
	PR_NON(A_OctetAligned oc2 = oc)
	PR_NONN(for (i = 0 ; i < oc2.size() ; i++){)
	    PR_INT(oc2[i])
	PR_NONE(})
	PR_STR(oc.asValueNotation().data())

	PR_NON(A_PrintableString pp)
	PR_NON(pp = "ABCD")
	PR_STR(pp.data())
	PR_STR(pp.asValueNotation().data())

	PR_NON(A_GeneralizedTime tt(1997,3,21,21))
	PR_INT(tt.get_year())
	PR_INT(tt.get_month())
	PR_INT(tt.get_day())
	PR_INT(tt.get_hour())
	PR_INT(tt.get_minute())
	PR_INT(tt.get_second())
	PR_INT(tt.get_millisec())
	PR_INT(tt.get_mindiff())
	PR_INT(tt.get_utc())
	PR_NON(tt.set_second(32))
	PR_INT(tt.get_second())
	PR_STR(tt.asValueNotation().data())
    }
    PR_NONE(catch (std::exception ex){)
	PR_STR(ex.what())
    PR_NONN(})

    {
    PR_NON(A_DN dn)
    PR_INT(dn.MOtoDN(A_TOP::localRootMO()))
    PR_NON((*dn.back().begin()).ref_attributeValue().memberGet(1)
		->valSetStr("AlltN"))
    PR_NON(A_RDN::iterator rit = dn.push_back().insert())
    PR_NON((*rit).set_attributeType().valSetStr("managedElementId"))
    PR_NON((*rit).set_attributeValue().labelMemberNew("pString")
		->valSetStr("Level2"))
    PR_NON(rit = (*dn.insert(dn.end())).insert())
    PR_NON((*rit).set_attributeType().valSetStr("managedElementId"))
    PR_NON((*rit).set_attributeValue().labelMemberNew("pString")
		->valSetStr("Level3"))
    //PR_NON(A_TOP *mo = dn.DNtoMO(MAKE_OUTSIDEMO,"test-object3"))
    PR_NON(A_TOP *mo = dn.DNtoMO(MAKE_OUTSIDEMO))
    PR_NON(ATTOP *at = newAttribute("attr-int"))
    PR_NON(at->valSetInt(100));
    PR_INT(mo->attributeWrite(at,TMG_MD_replace))
    }
}
