// $Id: aMain.cc,v 1.2 2007/08/15 02:19:42 tmn Exp $
// $Log: aMain.cc,v $
// Revision 1.2  2007/08/15 02:19:42  tmn
// localForm support
//
// Revision 1.1  2007/08/15 02:09:26  tmn
// Initial revision
//
// vi:ts=8:sw=4
//
//	Main program for alltypes sample
//

#include "tmgMib.h"
#include "tmgMibDynamic.h"

// Standard Console and Socket Console ----------------------------
#include "tmgCoSockMib.h"   /* Socket Console class */
#include "tmgCoEventMib.h"  /* Standard Console class */

/* 20070815 added by mochizuki localForm support start */
#include "cmUserImpl.h"

TmgCmUserImpl *g_user = NULL ;
/* 20070815 added by mochizuki localForm support end */

// Help Message ---------------------------------------------------
static void usage(int argc,char** argv)
{
    fprintf(stderr,"%s [options]\n",argv[0]);
    fprintf(stderr,"\
options:\n\
  -help			(Display this message)\n\
  -sockcons		(Use socket console)\n");

    tmgExpandOptionFile(argc,argv,"AP1");
    TmgReadMoDefinition(argc,argv);
    TmgMIBinitialize(argc,argv,NULL);
    TmgSockConsMIB sockCons;
    sockCons.Init(argc,argv);
}

// ----------------------------------------------------------------

int	main(int argc, char* argv[])
{
    int consoleType = TMG_STD_CONS;	// TMG_STD_CONS: Use Standard Console, 
					// TMG_SOCK_CONS: Use Socket Console

// -help�����뤫����
    if (tmgCmdLineOptionChk("-help",argc,argv)){
	usage(argc,argv);
	exit(1);
    }

// ���ץ����β��� --------------------------------------
    // ���ץ����ե������Ÿ��
    if (tmgExpandOptionFile(argc,argv,"AP1") < 0)
	exit(2);

    // ñ�����ץ����
    if (tmgCmdLineOption1("-sockcons",argc,argv)){
	consoleType = TMG_SOCK_CONS;
	printf("sockcons: on\n");
    }
    // �ɲ�MO����ɤ߹���
    TmgReadMoDefinition(argc,argv);

// Event Applications --------------------------------------
    YataEventHandler eventhandler;

// Initialize MIB interface --------------------------------------
/* 20070815 modified by mochizuki localForm support start */
//    TmgOpUser *user = new TmgOpUser;
//    if (TmgMIBinitialize(argc,argv,user) < 0)
    g_user = new TmgCmUserImpl ;
    if (TmgMIBinitialize(argc,argv,g_user) < 0)
        exit(1);
/* 20070815 modified by mochizuki localForm support end */

// User Applications --------------------------------------
    if(consoleType == TMG_SOCK_CONS || !isatty(0)){	// Use Socket Console
	TmgSockCons *sockCons = new TmgSockConsMIB;
	if (sockCons->Init(argc,argv) < 0) {
	    exit(1);
	}
    }
    else if(consoleType == TMG_STD_CONS){	// Use Standard Console
	TmgConsEvent *consEvent = new TmgConsEventMIB;
	if(consEvent->Init(argc,argv) < 0){
	    exit(1);
	}
    }

// Start Main Loop -----------------------------------------------------

    eventhandler.loop();

    return	0;
}
